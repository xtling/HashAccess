
% Trustworthy Grant-Free IoT Access Based on Blockchain
% FIG.3 PLOT

%% 
clear all;clc;close all;

%% input data
load('performance_collision');
H1 = hardlevel;
C = re_conflict_rate;
C = smoother(H1,C);
load('performance_time');
H2 = hardlevel;
D = re_delay_n;
D = D./200; % 1 second = 200 slots
load('performance_throughput');
H3 = hardlevel;
S = re_N./max(re_N).*0.001.*0.3908./0.3; % for the sake of aesthetic, the third output curve needs to be stretched
S = smoother(H3,S);
% our simulation results use difficulty 0~1 but the actual difficulty is 
% set to leading zero bits of hash arrays. The conversion must be made here
% to avoid unnecessary misunderstandings.
H1 = conv_diff2zero(H1,0);
H2 = conv_diff2zero(H2,0);
H3 = conv_diff2zero(H3,0);


%% output figure
color1 = [31 119 180]./255; % blue
color2 = [148 103 189]./255; % purple
color3 = [255 127 14]./255; % orange
x = figure(1);
box on;

yyaxis left;
plot(H1, C, 'LineStyle', '-', 'Marker', '*', 'Color', color1);
ylabel('Collision Prob.');
xlabel('Access Difficulty (# leading bits to be zeros)');

yyaxis right;
plot(H2, D, 'LineStyle', '-', 'Marker', '^', 'Color', color3);
ylim([0 1]);
ylabel('Random "Backoff" (s)');
set(x,'defaultAxesColorOrder',[color1; color3]);

hold on;
plot(H3, S*300, 'Color', 'k', 'LineStyle', '-', 'Marker', '+');
hold off;

% Due to the stretch of the third curve, an additional text arrow must be placed to
% point out the exact parameters of it.
annotation(x,'textarrow',[0.388392857142857 0.324404761904762],...
    [0.542650793650794 0.444444444444444],'String',{'Max throughput = 78 packets/s'},...
    'HeadStyle','cback3','FontSize', 16, 'FontName', 'Times New Roman','horizontalalignment','left');

grid on;
legend(["collision prob.";'random "backoff"';"throughput"], 'Location', 'northeast', 'FontName', 'Helvetica', 'FontSize', 16);

