
% Trustworthy Grant-Free IoT Access Based on Blockchain
% FIG.3 Data Generation
% The following 3 subsections of code may not be that efficient due to the
% separate design of each. Some repeated part can be ignored when reviewing

%% [1] packet collision rate versus difficulty
close all; clc;clear all;

% configuration - global variables
% the next 2 simulations are all using these parameters.
leng = 2^14; % simulation length
hardlevel = [0.05:0.05:0.90 0.905:0.005:0.995]; % sequence of difficulty for simulation
iot_num = 4; % the max iot device number is set to 4

% global variables for recording performance
re_delay = zeros(1,length(hardlevel));
re_delay_n = zeros(1,length(hardlevel));
re_vacant_rate = zeros(1,length(hardlevel));
re_avg_occupation_num = zeros(1,length(hardlevel));
re_conflict_rate = zeros(1,length(hardlevel));
re_M = zeros(1, length(hardlevel));
re_N = zeros(1, length(hardlevel));

% simulation
for d = 1:length(hardlevel)
    difficulty = hardlevel(d);
    c = timenow();
    iot_wait_time = zeros(1,iot_num);
    M=0; N=0;
    result_wait = [];
    result_conflict = zeros(1,leng);
    iot_wait_time_n = zeros(1,iot_num);
    result_wait_n = [];
    % calculate delay
    for l = 1:leng
        t = num2str(floor(str2num(c)) + l);
        r = checkhash(hash_sim(iot_num,1), difficulty, true);
        s = sum(r);
        M = M+s;
        result_conflict(l) = result_conflict(l) + s;
        iot_wait_time = iot_wait_time + 1;
        iot_wait_time_n = iot_wait_time_n + 1;
        if s == 1
            N = N+1;
            result_wait = [result_wait iot_wait_time(r==true)];
            iot_wait_time(r==true) = 0;
        end
        result_wait_n = [result_wait_n iot_wait_time_n(r==true)];
        iot_wait_time_n(r==true) = 0;
    end
    conflict_count = sum(result_conflict(find(result_conflict>1)));
    re_M(d) = M;
    re_N(d) = N;
    re_delay(d) = mean(result_wait);
    re_delay_n(d) = mean(result_wait_n);
    re_vacant_rate(d) = length(find(result_conflict==0))/length(result_conflict);
    re_avg_occupation_num(d) = mean(result_conflict);
    re_conflict_rate(d) = conflict_count/sum(result_conflict);
end

% output the trend curve and save result data
re_M = re_M./leng;
re_N = re_N./leng;
figure(1);
hold on;
plot(hardlevel, re_conflict_rate);
save('performance_collision','hardlevel','re_conflict_rate');
hold off;

% preview figures
figure();
grid on;
title('Collision Prob vs Difficulty');
xlabel("difficulty");
ylabel("collision probability");


%% [2] throughput versus difficulty
clc;

% configuration
leng = 2^14;
hardlevel = [0.05:0.05:0.90 0.90:0.01:0.99];

% global variables for recording performance
re_delay = zeros(1,length(hardlevel));
re_delay_n = zeros(1,length(hardlevel));
re_vacant_rate = zeros(1,length(hardlevel));
re_avg_occupation_num = zeros(1,length(hardlevel));
re_conflict_rate = zeros(1,length(hardlevel));
re_M = zeros(1, length(hardlevel));
re_N = zeros(1, length(hardlevel));

% simulation
for d = 1:length(hardlevel)
    difficulty = hardlevel(d);
    c = timenow();
    iot_wait_time = zeros(1,iot_num);
    M=0; N=0;
    result_wait = [];
    result_conflict = zeros(1,leng);
    iot_wait_time_n = zeros(1,iot_num);
    result_wait_n = [];
    % calculate delay
    for l = 1:leng
        t = num2str(floor(str2num(c)) + l);
        r = checkhash(hash_sim(iot_num,1), difficulty, true);
        s = sum(r);
        M = M+s;
        result_conflict(l) = result_conflict(l) + s;
        iot_wait_time = iot_wait_time + 1;
        iot_wait_time_n = iot_wait_time_n + 1;
        if s == 1
            N = N+1;
            result_wait = [result_wait iot_wait_time(r==true)];
            iot_wait_time(r==true) = 0;
        end
        result_wait_n = [result_wait_n iot_wait_time_n(r==true)];
        iot_wait_time_n(r==true) = 0;
    end
    conflict_count = sum(result_conflict(find(result_conflict>1)));
    re_M(d) = M;
    re_N(d) = N;
    re_delay(d) = mean(result_wait);
    re_delay_n(d) = mean(result_wait_n);
    re_vacant_rate(d) = length(find(result_conflict==0))/length(result_conflict);
    re_avg_occupation_num(d) = mean(result_conflict);
    re_conflict_rate(d) = conflict_count/sum(result_conflict);
end

% output the trend curve and save result data
re_M = re_M./leng;
re_N = re_N./leng;
figure(1);
hold on;
plot(hardlevel, re_N);
save('performance_throughput','hardlevel','re_N');
hold off;

% preview figures
figure();
grid on;
title('Throughput vs difficulty');
xlabel("difficulty");
ylabel("throughput");


%% [3] Backoff Time versus Difficulty

clc;

% configuration
leng = 2^14;
hardlevel = [0.05:0.05:0.90 0.905:0.005:0.995];
    
% global variables for recording performance
re_delay = zeros(1,length(hardlevel));
re_delay_n = zeros(1,length(hardlevel));
re_vacant_rate = zeros(1,length(hardlevel));
re_avg_occupation_num = zeros(1,length(hardlevel));
re_conflict_rate = zeros(1,length(hardlevel));

% simulation
for d = 1:length(hardlevel)
    difficulty = hardlevel(d);
    c = timenow();
    iot_wait_time = zeros(1,iot_num);
    result_wait = [];
    result_conflict = zeros(1,leng);
    iot_wait_time_n = zeros(1,iot_num);
    result_wait_n = [];
    % calculate delay
    for l = 1:leng
        t = num2str(floor(str2num(c)) + l);
        r = checkhash(hash_sim(iot_num,1), difficulty, true);
        s = sum(r);
        result_conflict(l) = result_conflict(l) + s;
        iot_wait_time = iot_wait_time + 1;
        iot_wait_time_n = iot_wait_time_n + 1;
        if s == 1
            result_wait = [result_wait iot_wait_time(r==true)];
            iot_wait_time(r==true) = 0;
        end
        result_wait_n = [result_wait_n iot_wait_time_n(r==true)];
        iot_wait_time_n(r==true) = 0;
    end
    conflict_count = sum(result_conflict(find(result_conflict>1)));

    % update global vars
    re_delay(d) = mean(result_wait);
    re_delay_n(d) = mean(result_wait_n);
end

% output the trend curve and save result data
figure();
plot(hardlevel, re_delay_n);
save('performance_time','hardlevel','re_delay_n');

% preview figures
grid on;
title('The time to find a valid hash vs Difficulty');
xlabel("difficulty");
ylabel("slot count (hash count)");
