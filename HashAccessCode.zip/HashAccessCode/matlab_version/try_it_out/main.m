% 'try it out' is the fastest way to try our proposed Hash Access scheme.
% By setting your own favourite parameters, the simulation will display a
% pop-up window to actually run Hash Access in your given configuration.
% The recording parameters include throughput, access difficulty, traffic
% load, and latency.

clc; clear all; close all;

%% Initial Parameters (you can only modify this part)

ini_difficulty = 1;                             % unit: amount of pre-leading zeroes of SHA256
ini_traffic_load = [2 12 6 1 13 5 10 1];        % unit: packets/slot (each number will last for a second in the simulation)
hash_freq = 50;                                 % unit: slots/second (the less the faster of the simulation)
opt = 2;                                        % unit: operators (APs)

%% Initialization 

ini_possibility = 1 / 2^ini_difficulty;
sim_length = length(ini_traffic_load);
len = hash_freq * sim_length;

% Definition of Simulation Variables
change_count = len;                     % the total slots for simulation
P = [];                                 % the list of max traffic load
load('dyn');                            % input adaptive difficulty table
traffic_list = [];                      % the list of traffic load
difficulty = ini_possibility;           % the initial access difficulty
for i = 1:length(ini_traffic_load)      % traffic allocation
    traffic = ceil(rand(1,change_count/length(ini_traffic_load)).*ini_traffic_load(i)+1);
    traffic_list = [traffic_list traffic];
    P = [P ones(1,change_count/length(ini_traffic_load)).*ini_traffic_load(i)+1];
end
re_M = zeros(1, ceil(change_count));        % result
re_G = zeros(1, ceil(change_count));        % result
re_N = zeros(1, ceil(change_count));        % result
re_delay = zeros(1, ceil(change_count));    % result
re_diff = zeros(1, ceil(change_count));     % result
re_devices = zeros(1, ceil(change_count));  % result

%% Simulation and Animation

% Pre-Format the Output Figure
figure(); hold on;
subplot(4,1,1); ylabel({'Traffic Load','(packets/s)'}); grid on; hold on;
subplot(4,1,2); ylabel({'Throughput','(packets/s)'}); grid on; hold on;
subplot(4,1,3); ylabel({'Latency','(s)'}); grid on; hold on;
subplot(4,1,4); ylabel({'Access','Difficulty'}); xlabel("t (s)"); grid on; hold on;

% Start Filming Simulation
for ii = 1:change_count
    leng = 2^14; % simulation length

    % Adjust Access Difficulty
    change_freq = ceil(hash_freq / 3)+20; % difficulty is changed every hash_freq/3+20 slots according to the past hash_freq/3+20 slots
    if mod(ii,change_freq) == 0 && ii-change_freq >= 0
        difficulty = diff_list(ceil(mean(traffic_list(ii-change_freq+1:ii)))); 
    end
    re_diff(ii) = difficulty;

    % Simulate the ii-th slot
    iot_num = traffic_list(ii); 
    re_devices(ii) = iot_num;
    result_wait = [];
    r = checkhash(hash_sim(iot_num,leng), difficulty, true);
    all_trans_slot = double(r == true);
    ts = sum(r,1);
    re_M(ii) = re_M(ii) + sum(ts);
    s = sum(r,1);
    result_conflict = s;
    no_conflict_ind = find(result_conflict==1);
    re_N(ii) = re_N(ii) + length(no_conflict_ind);
    [row,col] = find(r==true);
    [row,row_i] = sort(row);
    col = col(row_i);
    lat_n = diff(col);
    result_wait_n = sum(lat_n(find(lat_n>=0)));
    [~,t] = ismember(no_conflict_ind,col);
    no_conflict_device = row(t)';
    all_trans_slot(sub2ind(size(all_trans_slot),no_conflict_device,no_conflict_ind)) = 2;
    iot_wait_time = zeros(1,iot_num);
    iot_has_record = zeros(1,iot_num);
    iot_has_trans = zeros(1,iot_num);
    for l = 1:leng
        iot_wait_time = iot_wait_time + 1;
        ind1 = find(all_trans_slot(:,l)==1);
        ind2 = find(all_trans_slot(:,l)==2);
        iot_wait_time(ind1) = iot_has_record(ind1) .* iot_wait_time(ind1);
        iot_has_record(ind1) = 1;
        iot_has_trans(ind1) = 0;
        if iot_has_trans(ind2)==0
            result_wait = [result_wait iot_wait_time(ind2)];
            iot_has_trans(ind2) = 1;
            iot_has_record(ind2) = 0;
        end
    end
    
    % Process Results and Plot
    re_delay(ii) = mean(result_wait);
    re_G(ii) = re_M(ii)/leng;
    axis_pos = ceil(ii/hash_freq);    
    if ii > 1
        refresh_graph(ii/hash_freq, [re_G(ii), re_N(ii)./leng, re_delay(ii), conv_diff2zero(re_diff(ii))], (ii-1)/hash_freq, ...
            [re_G(ii-1), re_N(ii-1)./leng, re_delay(ii-1), conv_diff2zero(re_diff(ii-1))], axis_pos);
    else
        refresh_graph(1/hash_freq, [re_G(ii), re_N(ii)./leng, re_delay(ii), conv_diff2zero(re_diff(ii))], 0, ...
            [re_G(ii), re_N(ii)./leng, re_delay(ii), conv_diff2zero(re_diff(ii))], axis_pos);
    end
    
    % Animation
    m(ii) = getframe;

end


%% Animation

movie(m,2);

