function refresh_graph(t, data, old_t, old_data, xmax)

    hold on;
    colors = [174 199 232; 255 187 120; 152 223 138; 255 152 150]./255;
    
    subplot(4,1,1); fill([old_t t t old_t], [0 0 data(1) old_data(1)], colors(1,:), 'EdgeColor', 'none'); xlim([0 xmax]); hold on;
    subplot(4,1,2); fill([old_t t t old_t], [0 0 data(2) old_data(2)], colors(2,:), 'EdgeColor', 'none'); xlim([0 xmax]); hold on;
    subplot(4,1,3); fill([old_t t t old_t], [0 0 data(3) old_data(3)], colors(3,:), 'EdgeColor', 'none'); xlim([0 xmax]); hold on;
    subplot(4,1,4); fill([old_t t t old_t], [0 0 data(4) old_data(4)], colors(4,:), 'EdgeColor', 'none'); xlim([0 xmax]); hold on;
    
    subplot(4,1,1); plot([old_t t], [old_data(1) data(1)], 'k-'); hold on;
    subplot(4,1,2); plot([old_t t], [old_data(2) data(2)], 'k-'); hold on;
    subplot(4,1,3); plot([old_t t], [old_data(3) data(3)], 'k-'); hold on;
    subplot(4,1,4); plot([old_t t], [old_data(4) data(4)], 'k-'); hold on;
    
end

