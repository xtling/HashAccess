
% Trustworthy Grant-Free IoT Access Based on Blockchain
% FIG.4 PLOT

%% 
clear all;clc;close all;

%% input
scaler = 200; % 1 second = 200 slots
load('dynamic_monitor');
A1 = A./scaler; % slot -> second
D1 = D./scaler;
G1 = G;
Q1 = Q;
S1 = S;
V1 = V;
P1 = P;
O1 = conv_diff2zero(O);


%% process data and plot figure
figure(1);
box on;
hold on;

% pre-process data
% the precision of the original data is slot and the final output needs to
% make an average moving window on the data to make the curve more smooth.
V1 = moving_win(G1,scaler*1.5);
[A3,V3]=wave_plastic(A1,V1);
B3 = zeros(1,length(A3));
D1 = moving_win(D1,scaler*1.5);
S1 = moving_win(S1,scaler*1.5);
S1 = S1 .* scaler;
B4 = zeros(1,length(A1));

color1 = [174 199 232]./255;
color2 = [255 187 120]./255;
color3 = [152 223 138]./255;
color4 = [255 152 150]./255;

V3 = V3 .* scaler;

% start plotting data
subplot(4,2,[1 2]); 
SF1 = fill([A3,fliplr(A3)],[V3,fliplr(B3)], color1); 
set(SF1,{'LineStyle'},{'none'});
ylabel({'Traffic Load','(packets/s)'}); grid on; xlim([600 5200]./scaler);box on;


subplot(4,2,[3 4]); 
plot(A1,O1,'-','Color',color2,'LineWidth',2); 
ylabel({'Access','Difficulty'}); grid on; xlim([600 5200]./scaler); ylim([0 8]);box on;


subplot(4,2,[5 6]); 
SF3 = fill([A1,fliplr(A1)],[S1,fliplr(B4)], color3); 
set(SF3,{'LineStyle'},{'none'});
ylabel({'Throughput','(packets/s)'}); grid on; xlim([600 5200]./scaler);box on;


subplot(4,2,[7 8]); 
SF4 = fill([A1,fliplr(A1)],[D1,fliplr(B4)], color4); 
set(SF4,{'LineStyle'},{'none'});
ylabel({'Latency','(s)'}); grid on; xlim([600 5200]./scaler); xlabel("Time (s)");
ylim([0 5]); box on;


% final output
grid on;