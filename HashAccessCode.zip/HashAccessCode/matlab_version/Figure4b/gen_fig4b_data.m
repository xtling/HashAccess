
% Trustworthy Grant-Free IoT Access Based on Blockchain
% FIG.4 data generation

%% the running chart in the paper
clear all;clc;close all;

while true
    disp('start simulating...');
    
    %% Traffic Load allocation
    segs = [4 20 3 3 30 70 10 50]; % the given max number of IoT devices for each 700 slots
    change_count = 5600; % the total slots for simulation
    P = [];  % the list of max traffic load
    load('dyn'); % input adaptive difficulty table
    traffic_list = []; % the list of traffic load
    for i = 1:length(segs) % traffic allocation
        traffic = ceil(rand(1,change_count/length(segs)).*segs(i)+1);
        traffic_list = [traffic_list traffic];
        % the traffic load will change for every 700 slots (3.5 seconds)
        P = [P ones(1,change_count/length(segs)).*segs(i)+1];
    end

    T0 = 0.001;
    B = 0.1;
    difficulty = 1-1/(B/T0); % the initial difficulty

    %% initialize recording parameters, same as fig1 declaration
    re_M = zeros(1, ceil(change_count));
    re_G = zeros(1, ceil(change_count));
    re_N = zeros(1, ceil(change_count));
    re_delay = zeros(1, ceil(change_count));
    re_diff = zeros(1, ceil(change_count));
    re_devices = zeros(1, ceil(change_count));

    %% Simulation
    for ii = 1:change_count
        opt = 2;
        leng = 2^14; % simulation length

        % adaptive diff
        change_freq = 500; % difficulty is changed every 500 slots (2.5 seconds) according to the past 500 slots
        if mod(ii,change_freq) == 0 && ii-change_freq >= 0
            difficulty = diff_list(ceil(mean(traffic_list(ii-change_freq+1:ii)))); 
        end
        re_diff(ii) = difficulty;

        % assign the given traffic (max iot number) for the current loop
        iot_num = traffic_list(ii); 
        re_devices(ii) = iot_num;
        result_wait = [];
        r = checkhash(hash_sim(iot_num,leng), difficulty, true);
        all_trans_slot = double(r == true);
        ts = sum(r,1);
        re_M(ii) = re_M(ii) + sum(ts);
        s = sum(r,1);
        result_conflict = s;
        no_conflict_ind = find(result_conflict==1);
        re_N(ii) = re_N(ii) + length(no_conflict_ind);
        [row,col] = find(r==true);
        [row,row_i] = sort(row);
        col = col(row_i);
        lat_n = diff(col);
        result_wait_n = sum(lat_n(find(lat_n>=0)));
        [~,t] = ismember(no_conflict_ind,col);
        no_conflict_device = row(t)';
        all_trans_slot(sub2ind(size(all_trans_slot),no_conflict_device,no_conflict_ind)) = 2;
        iot_wait_time = zeros(1,iot_num);
        iot_has_record = zeros(1,iot_num);
        iot_has_trans = zeros(1,iot_num);
        for l = 1:leng
            iot_wait_time = iot_wait_time + 1;
            ind1 = find(all_trans_slot(:,l)==1);
            ind2 = find(all_trans_slot(:,l)==2);
            iot_wait_time(ind1) = iot_has_record(ind1) .* iot_wait_time(ind1);
            iot_has_record(ind1) = 1;
            iot_has_trans(ind1) = 0;
            if iot_has_trans(ind2)==0
                result_wait = [result_wait iot_wait_time(ind2)];
                iot_has_trans(ind2) = 1;
                iot_has_record(ind2) = 0;
            end
        end

        re_delay(ii) = mean(result_wait);
        re_G(ii) = re_M(ii)/leng;

    end

    % save result
    G = re_G;
    S = re_N./leng;
    Q = re_N./re_M;
    D = re_delay;
    A = 1:change_count;
    V = re_devices;
    O = re_diff;
    
    break;
    
end

%% save data and output figures

save('dynamic_monitor','G','S','Q','D','A','V','O','P');

figure(1);
hold on;
plot(A, G, 'k-+');
xlabel('time');
ylabel('traffic load');
grid on;

figure(2);
hold on;
plot(A, S, 'k-+');
xlabel('time');
ylabel('throughput');
grid on;

figure(3);
hold on;
plot(A, re_diff, 'k-+');
xlabel('time');
ylabel('difficulty');
grid on;

figure(4);
hold on;
plot(A, Q, 'k-+');
xlabel('time');
ylabel('successful rate');
grid on;

figure(5);
hold on;
plot(A, D, 'k-+');
xlabel('time');
ylabel('latency');
grid on; 

figure(6);
hold on;
plot(A, V, 'k-+');
xlabel('time');
ylabel('traffic');
grid on; 
