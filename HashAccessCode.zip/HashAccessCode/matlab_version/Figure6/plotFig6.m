
% Trustworthy Grant-Free IoT Access Based on Blockchain
% FIG.2 PLOT

%% 
clear all;clc;close all;

%% input data
load('loadtest_hash_access_balanced');
DD1 = re_delay;
GG1 = G;
SS1 = S;
QQ1 = Q;
load('loadtest_slotted_aloha_balanced');
DD2 = DD;
GG2 = GG;
SS2 = SS;
QQ2 = QQ;
load('loadtest_hash_access_unbalanced');
DD3 = re_delay;
GG3 = G;
SS3 = S;
QQ3 = Q;
load('loadtest_slotted_aloha_unbalanced');
DD4 = DD;
GG4 = GG;
SS4 = SS;
QQ4 = QQ;

% convert slots to seconds (scaler = 200)
DD1 = DD1./200;
DD2 = DD2./200;
DD3 = DD3./200;
DD4 = DD4./200;
GG1 = GG1.*200;
GG2 = GG2.*200;
GG3 = GG3.*200;
GG4 = GG4.*200;
SS1 = SS1.*200;
SS2 = SS2.*200;
SS3 = SS3.*200;
SS4 = SS4.*200;


%% output figure

figure(1);
l=["Hash Access (balanced)"; "Aloha (balanced)"; "Hash Access (unbalanced)"; "Aloha (unbalanced)"];
box on;
hold on;
SS1 = SS1./2;
SS2 = SS2./2;
SS3 = SS3./2;
SS4 = SS4./2;
plot(GG1, SS1, 'Color',[31 119 180]./255, 'Marker', '+');
plot(GG2, SS2, 'Color',[255 127 14]./255, 'Marker', 'o');
plot(GG3, SS3, 'Color',[214 39 40]./255, 'Marker', '^');
plot(GG4, SS4, 'Color',[44 160 44]./255, 'Marker', '*');
grid on;
xlabel("Traffic Load (packets/s)");
ylabel("Throughput (packets/s)");
xlim([0 2].*200);
legend(l,'Location','southeast');
PrintFigToPaper('-depsc', 'net_lay_SG', 16, 'Times New Roman', 7, 1, 0);
PrintFigToPaper('-dpng', 'net_lay_SG', 16, 'Times New Roman', 7, 1, 0);

figure(2);
box on;
hold on;
plot(GG1, QQ1, 'Color',[31 119 180]./255, 'Marker', '+');
plot(GG2, QQ2, 'Color',[255 127 14]./255, 'Marker', 'o');
plot(GG3, QQ3, 'Color',[214 39 40]./255, 'Marker', '^');
plot(GG4, QQ4, 'Color',[44 160 44]./255, 'Marker', '*');
grid on;
xlabel("Traffic Load (packets/s)");
ylabel("Successful Access Prob.");
xlim([0 2].*200);
legend(l);
PrintFigToPaper('-depsc', 'net_lay_QG', 16, 'Times New Roman', 7, 1, 0);
PrintFigToPaper('-dpng', 'net_lay_QG', 16, 'Times New Roman', 7, 1, 0);

figure(3);
box on;
plot(GG1, DD1, 'Color',[31 119 180]./255, 'Marker', '+');
hold on;
plot(GG2, DD2, 'Color',[255 127 14]./255, 'Marker', 'o');
plot(GG3, DD3, 'Color',[214 39 40]./255, 'Marker', '^');
plot(GG4, DD4, 'Color',[44 160 44]./255, 'Marker', '*');
grid on;
xlabel("Traffic Load (packets/s)");
ylabel("Latency (s)");
xlim([0.2 1].*200);
legend(l,'Location','southeast');
PrintFigToPaper('-depsc', 'net_lay_DG', 16, 'Times New Roman', 7, 1, 0);
PrintFigToPaper('-dpng', 'net_lay_DG', 16, 'Times New Roman', 7, 1, 0);
