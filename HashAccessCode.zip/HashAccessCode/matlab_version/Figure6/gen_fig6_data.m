
% Trustworthy Grant-Free IoT Access Based on Blockchain
% FIG.2 Data Generation

clear all; clc; close all;

switcher = [true true true]; % debug controller
thre = 2; % when traffic load exceeding 2 packets/slot, stop simulating.

%% HASH ACCESS - NETWORK LAYER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  HASH ACCESS BALANCE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if switcher(1)
    disp("start simulating: Hash Access Balanced...");
    opt = 2;
    leng = 2^17; % simulation length
    T0 = 0.001;
    B = 0.1;
    difficulty = 1-1/(B/T0/1); % test difficulty
    iot_num_list = 2:2000000; % list of numbers of iot devices
    T0 = 0.001;

    re_M = zeros(1, length(iot_num_list));
    re_G = zeros(1, length(iot_num_list));
    re_N = zeros(1, length(iot_num_list));
    re_delay = zeros(1, length(iot_num_list));
    re_delay_n = zeros(1, length(iot_num_list));
    re_avg_occupation_num = zeros(1, length(iot_num_list));
    re_conflict_rate = zeros(1, length(iot_num_list));

    for iot_num_ind = 2:8:length(iot_num_list)
        iot_num_s = iot_num_list(iot_num_ind);
        result_wait = [];
        for iot_num = [iot_num_s iot_num_s]
            r = checkhash(hash_sim(iot_num,leng), difficulty, true);
            all_trans_slot = double(r == true);
            ts = sum(r,1);
            re_M(iot_num_ind) = re_M(iot_num_ind) + sum(ts);
            s = sum(r,1);
            result_conflict = s;
            no_conflict_ind = find(result_conflict==1);
            re_N(iot_num_ind) = re_N(iot_num_ind) + length(no_conflict_ind);
            [row,col] = find(r==true);
            [row,row_i] = sort(row);
            col = col(row_i);
            lat_n = diff(col);
            result_wait_n = sum(lat_n(find(lat_n>=0)));
            [~,t] = ismember(no_conflict_ind,col);
            no_conflict_device = row(t)';
            all_trans_slot(sub2ind(size(all_trans_slot),no_conflict_device,no_conflict_ind)) = 2;
            iot_wait_time = zeros(1,iot_num);
            iot_has_record = zeros(1,iot_num);
            iot_has_trans = zeros(1,iot_num);
            % calculate delay
            for l = 1:leng
                iot_wait_time = iot_wait_time + 1;
                ind1 = find(all_trans_slot(:,l)==1);
                ind2 = find(all_trans_slot(:,l)==2);
                iot_wait_time(ind1) = iot_has_record(ind1) .* iot_wait_time(ind1);
                iot_has_record(ind1) = 1;
                iot_has_trans(ind1) = 0;
                if iot_has_trans(ind2)==0
                    result_wait = [result_wait iot_wait_time(ind2)];
                    iot_has_trans(ind2) = 1;
                    iot_has_record(ind2) = 0;
                end
            end
        end

        re_delay(iot_num_ind) = mean(result_wait);
        re_G(iot_num_ind) = re_M(iot_num_ind)/leng./opt;

        % terminate condition
        if re_G(iot_num_ind) > thre
            break;
        end

    end

    re_G(re_G==0) = [];
    re_M(re_M==0) = [];
    re_N(re_N==0) = [];
    re_delay(re_delay==0) = [];

    % output figure
    G = re_G;
    S = re_N./leng;
    Q = re_N./re_M;
    re_delay = re_delay./opt;
    save('loadtest_hash_access_balanced','G','S','Q','re_delay');
    figure(1);
    hold on;
    plot(G, S);
    grid on;
    figure(2);
    hold on;
    plot(G, Q);
    grid on;
    figure(3);
    hold on;
    plot(G, re_delay);
    grid on;
end


%% HASH ACCESS - NETWORK LAYER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  HASH ACCESS UNBALANCE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if switcher(1)
    disp("start simulating: Hash Access Unbalanced...");
    opt = 2;
    leng = 2^17;
    T0 = 0.001;
    B = 0.1;
    difficulty = 1-1/(B/T0/1);
    iot_num_list = 2:2000000;
    T0 = 0.001;

    re_M = zeros(1, length(iot_num_list));
    re_G = zeros(1, length(iot_num_list));
    re_N = zeros(1, length(iot_num_list));
    re_delay = zeros(1, length(iot_num_list));
    re_delay_n = zeros(1, length(iot_num_list));
    re_avg_occupation_num = zeros(1, length(iot_num_list));
    re_conflict_rate = zeros(1, length(iot_num_list));

    for iot_num_ind = 2:10:length(iot_num_list)
        iot_num_s = iot_num_list(iot_num_ind);
        result_wait = [];
        for iot_num = [iot_num_s ceil(iot_num_s/7*3)]
            r = checkhash(hash_sim(iot_num,leng), difficulty, true);
            all_trans_slot = double(r == true);
            ts = sum(r,1);
            re_M(iot_num_ind) = re_M(iot_num_ind) + sum(ts);
            s = sum(r,1);
            result_conflict = s;
            no_conflict_ind = find(result_conflict==1);
            re_N(iot_num_ind) = re_N(iot_num_ind) + length(no_conflict_ind);
            [row,col] = find(r==true);
            [row,row_i] = sort(row);
            col = col(row_i);
            lat_n = diff(col);
            result_wait_n = sum(lat_n(find(lat_n>=0)));
            [~,t] = ismember(no_conflict_ind,col);
            no_conflict_device = row(t)';
            all_trans_slot(sub2ind(size(all_trans_slot),no_conflict_device,no_conflict_ind)) = 2;
            iot_wait_time = zeros(1,iot_num);
            iot_has_record = zeros(1,iot_num);
            iot_has_trans = zeros(1,iot_num);
            for l = 1:leng
                iot_wait_time = iot_wait_time + 1;
                ind1 = find(all_trans_slot(:,l)==1);
                ind2 = find(all_trans_slot(:,l)==2);
                iot_wait_time(ind1) = iot_has_record(ind1) .* iot_wait_time(ind1);
                iot_has_record(ind1) = 1;
                iot_has_trans(ind1) = 0;
                if iot_has_trans(ind2)==0
                    result_wait = [result_wait iot_wait_time(ind2)];
                    iot_has_trans(ind2) = 1;
                    iot_has_record(ind2) = 0;
                end
            end
        end

        re_delay(iot_num_ind) = mean(result_wait);
        re_G(iot_num_ind) = re_M(iot_num_ind)/leng./opt;

        % terminate condition
        if re_G(iot_num_ind) > thre
            break;
        end

    end

    re_G(re_G==0) = [];
    re_M(re_M==0) = [];
    re_N(re_N==0) = [];
    re_delay(re_delay==0) = [];

    % output figure
    G = re_G;
    S = re_N./leng;
    Q = re_N./re_M;
    re_delay = re_delay./opt;
    save('loadtest_hash_access_unbalanced','G','S','Q','re_delay');
    figure(1);
    hold on;
    plot(G, S);
    grid on;
    figure(2);
    hold on;
    plot(G, Q);
    grid on;
    figure(3);
    hold on;
    plot(G, re_delay);
    grid on;
end


%% SLOTTED ALOHA - NETWORK LAYER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SLOTTED ALOHA - 2 Operator with 1 Channel, 30% and 70% Load Allocation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if switcher(2)
    clc;
    opt = 2;
    disp("start simulating: Slotted Aloha Unbalanced...");
    MaxIter = 2000;
    GG = [];
    SS = [];
    QQ = [];
    DD = [];
    backoff_scaler = 0.1; % scaler for max backoff time
    for mm=2:5:MaxIter
        delay = [];
        n=10000;
        N=0;
        M=0;
        T=0;
        
        for m = [mm ceil(mm/3*7)] % a little trick here: simulating 30% and 70% unbalanced circumstances
            A=rand(m,n)*backoff_scaler;
            A=floor(A*1000)/1000;
            B=cumsum(A,2);
            if T==0
                T=B(1,n);
            end
            C=1:1:(m*n);
            for i=1:m
                for j=1:n
                    C(1,(i-1)*n+j)=B(i,j);
                end
            end
            [D,I]=sort(C);
            T0=0.001;

            DT = D;
            DT(find(DT>T)) = [];
            M = M + length(find(DT <= T));
            ET = diff(DT);
            N = N + length(find(ET >= T0));

            % calculate delay
            I(find(D>T)) = [];
            D(find(D>T)) = [];
            E = diff(D);
            DeviceI = ceil(I/n);
            for i=1:m
                ind = find(DeviceI==i);
                ind(find(ind>length(E))) = [];
                ind(find(ind==1)) = [];
                col_ind = ind(find(E(ind) < T0));
                counter_ind = col_ind;
                ok_ind = ind(find(E(ind) >= T0));
                event = [counter_ind ok_ind(end:-1:1)];
                [event_ind, event_order] = sort(event);
                event_ind(find(diff(event_order)==1) + 1) = [];
                [~,pos] = ismember(counter_ind, event_ind);
                pos(pos==0) = [];
                if ismember(event_ind(end), ok_ind)
                    delay = [delay (D(event_ind(pos + 1)) - D(event_ind(pos)))/T0];
                else
                    event_ind = event_ind(1:(length(event_ind)-1));
                    [~,pos] = ismember(counter_ind, event_ind);
                    pos(pos==0) = [];
                    delay = [delay (D(event_ind(pos + 1)) - D(event_ind(pos)))/T0];
                end
            end
            
        end

        % analyse and save result
        G=M/T*T0/opt; % same as fig1 declaration
        S=N/T*T0; 
        Q=N/M;
        D=mean(delay);

        GG = [GG G];
        SS = [SS S];
        QQ = [QQ Q];
        DD = [DD D];

        if G>thre
            break;
        end

    end

    save('loadtest_slotted_aloha_unbalanced','GG','SS','QQ','DD');
    figure(1);
    hold on;
    plot(GG, SS);
    grid on;
    figure(2);
    hold on;
    plot(GG, QQ);
    grid on;
    figure(3);
    hold on;
    plot(GG, DD);
    grid on;
end



%% SLOTTED ALOHA - NETWORK LAYER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SLOTTED ALOHA - 2 Operator with 1 Channel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if switcher(2)
    clc;
    opt = 2;
    disp("start simulating: Slotted Aloha Balanced...");
    MaxIter = 2000;
    GG = [];
    SS = [];
    QQ = [];
    DD = [];
    backoff_scaler = 0.1;
    for mm=2:3:MaxIter
        delay = [];
        n=10000;
        N=0;
        M=0;
        T=0;
        
        for m = [mm mm]
            A=rand(m,n)*backoff_scaler;
            A=floor(A*1000)/1000;
            B=cumsum(A,2);
            if T==0
                T=B(1,n);
            end
            C=1:1:(m*n);
            for i=1:m
                for j=1:n
                    C(1,(i-1)*n+j)=B(i,j);
                end
            end
            [D,I]=sort(C);
            T0=0.001;

            DT = D;
            DT(find(DT>T)) = [];
            M = M + length(find(DT <= T));
            ET = diff(DT);
            N = N + length(find(ET >= T0));

            % calculate delay
            I(find(D>T)) = [];
            D(find(D>T)) = [];
            E = diff(D);
            DeviceI = ceil(I/n);
            for i=1:m
                ind = find(DeviceI==i);
                ind(find(ind>length(E))) = [];
                ind(find(ind==1)) = [];
                col_ind = ind(find(E(ind) < T0));
                counter_ind = col_ind;
                ok_ind = ind(find(E(ind) >= T0));
                event = [counter_ind ok_ind(end:-1:1)];
                [event_ind, event_order] = sort(event);
                event_ind(find(diff(event_order)==1) + 1) = [];
                [~,pos] = ismember(counter_ind, event_ind);
                pos(pos==0) = [];
                if ismember(event_ind(end), ok_ind)
                    delay = [delay (D(event_ind(pos + 1)) - D(event_ind(pos)))/T0];
                else 
                    event_ind = event_ind(1:(length(event_ind)-1));
                    [~,pos] = ismember(counter_ind, event_ind);
                    pos(pos==0) = [];
                    delay = [delay (D(event_ind(pos + 1)) - D(event_ind(pos)))/T0];
                end
            end
            
        end

        % analyse and save result
        G=M/T*T0/opt; % same as fig1 declaration
        S=N/T*T0;
        Q=N/M;
        D=mean(delay);

        GG = [GG G];
        SS = [SS S];
        QQ = [QQ Q];
        DD = [DD D];

        if G>thre
            break;
        end

    end

    save('loadtest_slotted_aloha_balanced','GG','SS','QQ','DD');
    figure(1);
    hold on;
    plot(GG, SS);
    grid on;
    figure(2);
    hold on;
    plot(GG, QQ);
    grid on;
    figure(3);
    hold on;
    plot(GG, DD);
    grid on;
end



%% output figure
figure(1);
l=["hash access (balanced)"; "hash access (unbalanced)"; "s-aloha (unbalanced)"; "s-aloha (balanced)"];
hold on;
grid on;
xlabel("Traffic Load G");
ylabel("Throughput S");
xlim([0 thre]);
legend(l,'Location','southeast');

figure(2);
hold on;
grid on;
xlabel("Traffic Load G");
ylabel("successful rate Q");
xlim([0 thre]);
legend(l);

figure(3);
hold on;
grid on;
xlabel("Traffic Load G");
ylabel("number of slots");
xlim([0 1]);
legend(l,'Location','southeast');
