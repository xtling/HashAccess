function new_data = moving_win(x,leng)
    %MOVING_WIN �����ݼӻ�����
    if leng > length(x) || leng == 0
        new_data = [];
        return;
    end
    new_data = zeros(1,length(x));
    x = [x ones(1,leng-1).*x(end)];
    for i = 1:length(x)-leng+1
        new_data(i) = mean(x(i:i+leng-1));
    end
end