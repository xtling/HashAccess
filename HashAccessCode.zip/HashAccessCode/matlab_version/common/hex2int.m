function o = hex2int(h)
    if h <= '9'
        o = h - '0';
    else
        if h >= 'A' && h <= 'F'
            o = h - 'A' + 10;
        end
        if h >= 'a' && h <= 'f'
            o = h - 'a' + 10;
        end
    end
end

