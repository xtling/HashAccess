function o = binomial(p)
    %BINOMIAL ����ֲ�ȡֵ
    o = false;
    if rand() < p
        o = true;
    end
end

