function imei = gen_imei()
    %GEN_IMEI Ϊ�豸�������������ʱ�׼��imeiֵ
    %   imei:string
    r1 = 1000000 + randi(8999999);
    r2 = 1000000 + randi(8999999);
    input = [num2str(r1) num2str(r2)];
    a = 0;
    b = 0;
    for i = 1:strlength(input)
        tt = str2num(input(i));
        if mod(i,2) == 0
            a = a + tt;
        else
            temp = tt * 2;
            b = b + floor(temp / 10) + mod(temp,10);
        end
    end
    last = mod((a + b), 10);
    if last == 0
        last = 0;  
    else
        last = 10 - last;  
    end
    imei = [input num2str(last)];
end

