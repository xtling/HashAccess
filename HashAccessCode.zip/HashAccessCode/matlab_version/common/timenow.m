function o = timenow()
    t = clock;
    o = t(1)*10^6 + t(2)*10^5 + t(3)*10^4 + t(4)*10^3 + t(5)*10^2 + t(6);
    o = num2str(o);
end

