function f = wavecutaxes(blamp,blxpos,blwidth,blstart,blend)
    %WAVECUTAXES ʹ�ò����߷ָ�������
    c = [1 1 1];
    bly = blstart:0.1:blend;
    blx_left = sin(bly./(max(bly)-min(bly))*2*pi)*blamp + blxpos;
%     plot(blx_left,bly,'-','Color',c);
    blx_right = sin(bly./(max(bly)-min(bly))*2*pi)*blamp + blxpos + blwidth;
%     plot(blx_right,bly,'-','Color',c);
    patch('YData',[bly fliplr(bly)],'XData',[blx_left fliplr(blx_right)],...
        'LineStyle','none', 'FaceColor',[1 1 1]);
    f = true;
end

