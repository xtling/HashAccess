close all; clear all; clc;

% Trustworthy Grant-Free IoT Access Based on Blockchain
% FIG.5 PLOT

% input pre-formatted power consumption table for each device
[a,b,c] = xlsread('data_pwr.xlsx');
d = a(:,2);
a = a(:,1);
fig_size = [8 8/4*3];
offset = -0.15;
xmax = 69*1.15;

% data pre-process
tab_color = {'BC95 (NB-IoT)', [114,158,206]./255;
            'ZM8300G (NB-IoT)', [255,158,74]./255;
            'ESP8266EX (WiFi)', [103,191,92]./255;
            'SX1278 (LoRa)', [237,102,93]./255;
            'MTK MT6225A (Mobile)', [173,139,201]./255;
            'ST33F1M (Mobile)', [168,120,110]./255;
            'X6500 FPGA Miner (FPGA)', [237,151,202]./255;
            'BitForce SHA256 Single (FPGA)', [162,162,162]./255;
            'Avalon Batch 2 (ASIC)', [205,204,93]./255;
            'Antminer S3 (ASIC)', [109,204,218]./255};
for i = 1:length(b)
    if a(i)==0
        b(i) = cellstr(['\bf\color{blue}' cell2mat(b(i)) '\rm\color{black}']); 
    end
end

figure();
hold on;
    
% fill in data
height = length(d);
for i=1:height
    val_real = a(i);
    val_fake = d(i);
    line_axis = [0 val_fake];
    color = mat2cell([0 0 0],1);
    for j = 1:length(tab_color)
        if strcmp(char(tab_color(j,1)), char(b(i)))
            color = tab_color(j,2); 
        end
    end
    pos = i;
    line_lower = ones(1,length(line_axis)) .* (0.25*(height-pos));
    line_upper = ones(1,length(line_axis)) .* (0.25*(height-pos+1));
    fill([line_axis,fliplr(line_axis)],[line_upper,fliplr(line_lower)], cell2mat(color));
end

% format
set(gca, 'YTick', 0.125:0.25:(0.25*height), 'YTickLabel', flipud(b), 'TickLength', [0 0], 'FontSize', 15);
set(gca, 'XTick', [], 'XTickLabel',[], 'XColor','none');
xlim([0 xmax]);
ylim([-0.21 0.25*height]);

% cut axes
cutpos_start = [7.5 20.25] + 3;
cutpos_height = 0.25 * (height - [5 12 15 18] + 0.6);
cutlen = 2;
cutamp = 0;
axisoffset = -0.11;

start = 0;
for s = 1:length(cutpos_start) + 1
    if s <= length(cutpos_start)
        wavecutaxes(cutamp, cutpos_start(s), cutlen, axisoffset, cutpos_height(s));
        line([start cutpos_start(s)], [axisoffset axisoffset], 'Color', [0 0 0], 'LineWidth', 1);
        start = cutpos_start(s) + cutlen;
        slash_offset = 0.3;
        slash_height = 0.08;
        line([cutpos_start(s)-slash_offset cutpos_start(s)+slash_offset], [axisoffset-slash_height axisoffset+slash_height], 'Color', [0 0 0], 'LineWidth', 1);
        line([start-slash_offset start+slash_offset], [axisoffset-slash_height axisoffset+slash_height], 'Color', [0 0 0], 'LineWidth', 1);
    else
        arrow([start axisoffset], [xmax-start 0], [0 0 0], 1);
    end    
end

% re-tick axis
axis_text_pos = [5 9.5 15 20 30.5:5.4:75];
for tpos = 1:length(axis_text_pos)
    line([axis_text_pos(tpos) axis_text_pos(tpos)], [axisoffset axisoffset+slash_height], 'Color', [0 0 0], 'LineWidth', 1);
end
axis_text = {'0';'100nJ';'200nJ';'2\muJ';'20\muJ';'150mJ';'300mJ';'450mJ';'600mJ';'750mJ'};
axis_text_pos = [0 5 9.5 15 20 35.9:10.8:75]-0.5;
for tpos = 1:length(axis_text_pos)
    t = text(axis_text_pos(tpos),axisoffset*2,axis_text{tpos},'VerticalAlignment','middle','HorizontalAlignment','left','Color','black','fontsize',12);
    set(t, 'Rotation', -61.8);
    uistack(t, 'top');
end

% gap re-fill
fill_start = [cutpos_start Inf];
fill_end = [cutpos_start+cutlen Inf];
for i=1:height
    val_real = a(i);
    val_fake = d(i);
    j = 1;
    line_axis = [];
    while j <= length(fill_start)
        if val_fake < fill_start(j)
            break;
        end
        line_axis = [line_axis; fill_start(j) fill_end(j)];
        j = j + 1;
    end
    if j == 1 || val_fake == 0
        continue;
    end
    color = mat2cell([0 0 0],1);
    for j = 1:length(tab_color)
        if strcmp(char(tab_color(j,1)), char(b(i)))
            color = tab_color(j,2); 
        end
    end
    pos = i;
    for l = 1:length(line_axis(:,1))
        line_lower = ones(1,length(line_axis(l,:))) .* (0.25*(height-pos));
        line_upper = ones(1,length(line_axis(l,:))) .* (0.25*(height-pos+1));
        g = fill([line_axis(l,:),fliplr(line_axis(l,:))],[line_upper,fliplr(line_lower)], cell2mat(color));
        set(g, 'facealpha', 0.3);
        uistack(t, 'top');
    end
end

hold off;box off;

% text
for i = 1:height
    val_real = a(i);
    val_fake = d(i);
    pos = i;
    if i == 19
        if val_real > 1
            t = text(xmax - 17,0.125+(height-pos)*0.25,[' ' char(vpa(val_real,3)) 'mJ '],'VerticalAlignment','middle','HorizontalAlignment','left','Color','white');
        elseif val_real < 1e-3
            t = text(xmax - 17,0.125+(height-pos)*0.25,[' ' char(vpa(val_real*1e6,3)) 'nJ '],'VerticalAlignment','middle','HorizontalAlignment','left','Color','white');
        else
            t = text(xmax - 17,0.125+(height-pos)*0.25,[' ' char(vpa(val_real*1e3,3)) '{\mu}J '],'VerticalAlignment','middle','HorizontalAlignment','left','Color','white');
        end
        continue; 
    end
    if val_real>0
        xpos = val_fake;
        if val_real > 1
            t = text(xpos,0.125+(height-pos)*0.25,[' ' char(vpa(val_real,3)) 'mJ '],'VerticalAlignment','middle','HorizontalAlignment','left','Color','black');
        elseif val_real < 1e-3
            t = text(xpos,0.125+(height-pos)*0.25,[' ' char(vpa(val_real*1e6,3)) 'nJ '],'VerticalAlignment','middle','HorizontalAlignment','left','Color','black');
        else
            t = text(xpos,0.125+(height-pos)*0.25,[' ' char(vpa(val_real*1e3,3)) '{\mu}J '],'VerticalAlignment','middle','HorizontalAlignment','left','Color','black');
        end
        uistack(t,'top');
    end
end

mainPosition = get(gca,'Position');
set(gca,'Position',[mainPosition(1)+offset mainPosition(2) mainPosition(3)-offset mainPosition(4)]);
