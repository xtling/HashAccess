clear all; clc; close all;

% Trustworthy Grant-Free IoT Access Based on Blockchain
% FIG.1 CODE


%% HASH ACCESS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  HASH ACCESS with fixed and adaptive difficulty
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp("start simulating: Hash Access...");
leng = 2^17; % simulation length
diff1 = 0.98; % test fixed difficulty
iot_num_list_ha = 2:200; % list of number of iot devices
T0 = 0.001; % slot duration

re_M = zeros(1, length(iot_num_list_ha)); % list of transmission counter within the test time
re_N = zeros(1, length(iot_num_list_ha)); % list of  successful transmission counter within the test time
re_delay = zeros(1, length(iot_num_list_ha)); % list of transmission delay
re_delay_n = zeros(1, length(iot_num_list_ha)); % list of transmission delay without re-transmission circumstances
re_avg_occupation_num = zeros(1, length(iot_num_list_ha)); % list of average occupation rate within the test time
re_conflict_rate = zeros(1, length(iot_num_list_ha)); % list of average conflict rate within the test time

% the following parameters are declared similar to the ones above, but are
% only declared for testing adaptive difficulty.
re_M_dyn = zeros(1, length(iot_num_list_ha));
re_N_dyn = zeros(1, length(iot_num_list_ha));
re_delay_dyn = zeros(1, length(iot_num_list_ha));
re_delay_n_dyn = zeros(1, length(iot_num_list_ha));
re_avg_occupation_num_dyn = zeros(1, length(iot_num_list_ha));
re_conflict_rate_dyn = zeros(1, length(iot_num_list_ha));

load('dyn'); % input pre-generated adaptive difficulty table

for iot_num_ind = 2:6:length(iot_num_list_ha)
    iot_num = iot_num_list_ha(iot_num_ind);
    
    if length(find(iot_num_list==iot_num)) > 0
        diff2 = diff_list(find(iot_num_list==iot_num));
    elseif iot_num < 80
        diff2 = 0.993;
    elseif iot_num < 100
        diff2 = 0.996;
    else
        diff2 = 0.999;
    end
    diff_list_sel = [diff1 diff2];
    
    for diff_ind = 1:2
        difficulty = diff_list_sel(diff_ind);
        
        c = timenow();
        iot_wait_time = zeros(1,iot_num);
        result_wait = [];
        result_conflict = zeros(1,leng);
        iot_wait_time_n = zeros(1,iot_num);
        result_wait_n = [];
        for l = 1:leng
            t = num2str(floor(str2num(c)) + l);
            r = checkhash(hash_sim(iot_num,1), difficulty, true);
            s = sum(r);
            if diff_ind == 1
                re_M(iot_num_ind) = re_M(iot_num_ind) + s;
            else
                re_M_dyn(iot_num_ind) = re_M_dyn(iot_num_ind) + s;
            end
            result_conflict(l) = result_conflict(l) + s;
            iot_wait_time = iot_wait_time + 1;
            iot_wait_time_n = iot_wait_time_n + 1;
            if s == 1
                result_wait = [result_wait iot_wait_time(r==true)];
                iot_wait_time(r==true) = 0;
                if diff_ind == 1
                    re_N(iot_num_ind) = re_N(iot_num_ind) + 1;
                else
                    re_N_dyn(iot_num_ind) = re_N_dyn(iot_num_ind) + 1;
                end
            end
            result_wait_n = [result_wait_n iot_wait_time_n(r==true)];
            iot_wait_time_n(r==true) = 0;
        end

        % update global vars
        if diff_ind == 1 % save for fixed difficulty
            conflict_count = sum(result_conflict(find(result_conflict>1)));
            re_delay(iot_num_ind) = mean(result_wait);
            re_delay_n(iot_num_ind) = mean(result_wait_n);
            re_vacant_rate(iot_num_ind) = length(find(result_conflict==0))/length(result_conflict);
            re_avg_occupation_num(iot_num_ind) = mean(result_conflict);
            re_conflict_rate(iot_num_ind) = conflict_count/sum(result_conflict);
        else % save for adaptive difficulty
            conflict_count = sum(result_conflict(find(result_conflict>1)));
            re_delay_dyn(iot_num_ind) = mean(result_wait);
            re_delay_n_dyn(iot_num_ind) = mean(result_wait_n);
            re_vacant_rate_dyn(iot_num_ind) = length(find(result_conflict==0))/length(result_conflict);
            re_avg_occupation_num_dyn(iot_num_ind) = mean(result_conflict);
            re_conflict_rate_dyn(iot_num_ind) = conflict_count/sum(result_conflict);
        end
        
    end
    
    % terminate condition
    if re_M(iot_num_ind)/leng > 1.9999
        break;
    end
    
end

re_M(re_M==0) = [];
re_N(re_N==0) = [];
re_delay(re_delay==0) = [];

re_M_dyn(re_M_dyn==0) = [];
re_N_dyn(re_N_dyn==0) = [];
re_delay_dyn(re_delay_dyn==0) = [];

G = re_M./leng;
S = re_N./leng;
Q = re_N./re_M;
save('benchmark_honest_hash_access_without_control','G','S','Q','re_delay');

G_dyn = re_M_dyn./leng;
S_dyn = re_N_dyn./leng;
Q_dyn = re_N_dyn./re_M_dyn;
save('benchmark_honest_hash_access','G','G_dyn','S_dyn','Q_dyn','re_delay_dyn');
% NOTE that the generated throughput S_dyn and Q_dyn is only convincible
% when the traffic load G (not G_dyn) is 0.8~1.2, which is because the
% difficulty control will greatly affect the traffic load, and the best
% difficulty will always make traffic be around 0.8~1.2. However, the delay
% re_delay_dyn versus traffic G will not be affected due to the fact that 
% delay is counted for each single data packet.
% Since the scheme that adopts adaptive difficulty will not be sampled
% correctly out of the convincible range, we extends the curve according to
% the fixed difficulty for the sake of aesthetics.
% (unit: packets/slot)

figure(1);
hold on;
plot(G, S_dyn, 'g-*');
grid on;
figure(2);
hold on;
plot(G, Q_dyn, 'g-*');
figure(3);
hold on;
plot(G, re_delay_dyn, 'g-*');
grid on;

figure(1);
hold on;
plot(G, S, 'k-+');
grid on;
figure(2);
hold on;
plot(G, Q, 'k-+');
figure(3);
hold on;
plot(G, re_delay, 'k-+');
grid on;


%% SLOTTED ALOHA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SLOTTED ALOHA - Honest Network
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; clc;
disp("start simulating: Slotted Aloha...");
MaxIter = 2000;
GG = [];
SS = [];
QQ = [];
DD = [];
backoff_scaler = 0.1;
for m=2:4:MaxIter                % m stands for device number
    delay = [];
    n=8000;
    A=rand(m,n)*backoff_scaler;
    A=floor(A*1000)/1000;
    B=cumsum(A,2);
    T=B(1,n);
    C=1:1:(m*n);
    for i=1:m
        for j=1:n
            C(1,(i-1)*n+j)=B(i,j);
        end
    end
    [D,I]=sort(C);
    T0=0.001;
    N=0;
    M=0;
    DT = D;
    DT(find(DT>T)) = [];
    M = length(find(DT <= T));
    ET = diff(DT);
    N = length(find(ET >= T0));
    
    % calculate delay
    I(find(D>T)) = [];
    D(find(D>T)) = [];
    E = diff(D);
    DeviceI = ceil(I/n);
    for i=1:m
        ind = find(DeviceI==i);
        ind(find(ind>length(E))) = [];
        ind(find(ind==1)) = [];
        col_ind = ind(find(E(ind) < T0));
        counter_ind = col_ind;
        ok_ind = ind(find(E(ind) >= T0));
        event = [counter_ind ok_ind(end:-1:1)];
        [event_ind, event_order] = sort(event);
        event_ind(find(diff(event_order)==1) + 1) = [];
        [~,pos] = ismember(counter_ind, event_ind);
        pos(pos==0) = [];
        if ismember(event_ind(end), ok_ind)
            delay = [delay (D(event_ind(pos + 1)) - D(event_ind(pos)))/T0];
        else
            event_ind = event_ind(1:(length(event_ind)-1));
            [~,pos] = ismember(counter_ind, event_ind);
            pos(pos==0) = [];
            delay = [delay (D(event_ind(pos + 1)) - D(event_ind(pos)))/T0];
        end
    end
    
    % analysis.
    G=M/T*T0; % traffic load (unit:packets/slot)
    S=N/T*T0; % throughput (unit:packets/slot)
    Q=N/M; % successful transmission rate
    D=mean(delay); % average delay of packets
    
    GG = [GG G];
    SS = [SS S];
    QQ = [QQ Q];
    DD = [DD D];
   
    if G>1.9999
        break;
    end
    
end

save('benchmark_honest_aloha','GG','SS','QQ','DD');

figure(1);
hold on;
plot(GG, SS, 'b-');
figure(2);
hold on;
plot(GG, QQ, 'b-');
figure(3);
hold on;
plot(GG, DD, 'b-');



%% SLOTTED ALOHA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SLOTTED ALOHA - 10% selfish nodes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all; clc;
disp("start simulating: Slotted Aloha (10% selfish nodes)...");
MaxIter = 2000;
GG = [];
SS = [];
QQ = [];
DD = [];
selfish_p = 0.1; % selfish nodes proportion
selfish_degree = 0.5; % selfish degree, the lower the more selfish
backoff_scaler = 0.1;
for m=2:10:MaxIter
    sel_ind = floor(selfish_p*m);
    T0=0.001;
    delay = 0;
    n=160000;
    A=rand(m-sel_ind,n)*backoff_scaler;
    A=floor(A*1000)/1000;
    B=cumsum(A,2);
    T=B(1,n);
    C=1:1:((m-sel_ind)*n);
    for i=1:m-sel_ind
        for j=1:n
            C(1,(i-1)*n+j)=B(i,j);
        end
    end
    [D,I]=sort(C);
    
    % calculate actions of selfish nodes based on the data above 
    A2=rand(sel_ind,ceil(n/selfish_degree))*backoff_scaler*selfish_degree;
    A2=floor(A2*1000)/1000;
    B2=cumsum(A2,2);
    t = size(B2);
    t = t(2) - n;
    n = n + t;
    B = [B zeros(m-sel_ind,t)];
    
    % recover scene and combine the actions of honest and selfish nodes
    B=[B;B2];
    T=max(B(1,:));
    C=1:1:(m*n);
    for i=1:m
        for j=1:n
            C(1,(i-1)*n+j)=B(i,j);
        end
    end
    [D,I]=sort(C);
    
    N=0;
    M=0;
    DT = D;
    IT = I;
    IT(find(DT>T|DT==0)) = [];
    DT(find(DT>T|DT==0)) = [];
    DeviceI = ceil(IT/n);
    M = length(find(DeviceI <= m-sel_ind & DT <= T));
    ET = diff(DT);
    N = length(find(DeviceI <= m-sel_ind & [0 ET] >= T0));
    % the throughput and traffic load are successfully analyzed.
    
    % calculate delay
    I(find(D>T|D==0)) = [];
    D(find(D>T|D==0)) = [];
    E = diff(D);
    DeviceI = ceil(I/n);
    for i=1:m
        ind = find(DeviceI==i);
        ind(find(ind>length(E))) = [];
        ind(find(ind==1)) = [];
        col_ind = ind(find(E(ind) < T0));
        counter_ind = col_ind;
        ok_ind = ind(find(E(ind) >= T0));
        event = [counter_ind ok_ind(end:-1:1)];
        [event_ind, event_order] = sort(event);
        event_ind(find(diff(event_order)==1) + 1) = [];
        [~,pos] = ismember(counter_ind, event_ind);
        pos(pos==0) = [];
        if ismember(event_ind(end), ok_ind)
            delay = [delay (D(event_ind(pos + 1)) - D(event_ind(pos)))/T0];
        else
            event_ind = event_ind(1:(length(event_ind)-1));
            [~,pos] = ismember(counter_ind, event_ind);
            pos(pos==0) = [];
            delay = [delay (D(event_ind(pos + 1)) - D(event_ind(pos)))/T0];
        end
    end
    
    % analysis. same as honest aloha simulation
    G=M/T*T0;
    S=N/T*T0;
    Q=N/M;
    D=mean(delay);
    
    GG = [GG G];
    SS = [SS S];
    QQ = [QQ Q];
    DD = [DD D];
    
    if G > 1.999
        break; 
    end
    
end
save('benchmark_selfish_aloha','GG','SS','QQ','DD');

figure(1);
hold on;
plot(GG, SS, 'r-');
grid on;
xlabel("Traffic Load G");
ylabel("Throughput S");
xlim([0 2]);
legend(["HA(dynamic)"; "hash access"; "s-aloha (honest)"; "s-aloha (10% selfish)"],'Location','southeast');
figure(2);
hold on;
plot(GG, QQ, 'r-');
grid on;
xlabel("Traffic Load G");
ylabel("successful rate Q");
xlim([0 2]);
legend(["HA(dynamic)"; "hash access"; "s-aloha (honest)"; "s-aloha (10% selfish)"]);
figure(3);
hold on;
plot(GG, DD, 'r-');
grid on;
xlabel("Traffic Load G");
ylabel("number of slots");
% ylim([0 1000]);
xlim([0.2 1]);
legend(["HA(dynamic)"; "hash access"; "s-aloha (honest)"; "s-aloha (10% selfish)"]);
