
% Trustworthy Grant-Free IoT Access Based on Blockchain
% FIG.1 PLOT

%%
clear all; close all; clc;

%% input data
load('benchmark_honest_hash_access');
DD1 = re_delay_dyn;
GG1 = G;
DD1 = smoother(GG1,DD1);
GG0 = G_orig;
SS1 = S;
QQ1 = Q;
SS1 = smoother(GG0,SS1);
QQ1 = smoother(GG0,QQ1);

load('benchmark_honest_aloha');
DD2 = DD;
GG2 = GG;
SS2 = SS;
QQ2 = QQ;
DD2 = smoother(GG2,DD2);
SS2 = smoother(GG2,SS2);
QQ2 = smoother(GG2,QQ2);

load('benchmark_selfish_aloha');
DD3 = DD;
GG3 = GG;
SS3 = SS;
QQ3 = QQ;
DD3 = smoother(GG3,DD3);
SS3 = smoother(GG3,SS3);
QQ3 = smoother(GG3,QQ3);

load('benchmark_honest_hash_access_without_control');
DD4 = re_delay;
GG4 = G;
SS4 = S;
QQ4 = Q;
DD4 = smoother(GG4,DD4);
SS4 = smoother(GG4,SS4);
QQ4 = smoother(GG4,QQ4);

%% Scale the delay, throughput and traffic load to `seconds`
% the unit demonstrated in figures are all set to seconds.
% 1 second has 200 time slots.
DD1 = DD1./200;
DD2 = DD2./200;
DD3 = DD3./200;
DD4 = DD4./200;
GG0 = GG0.*200;
GG1 = GG1.*200;
GG2 = GG2.*200;
GG3 = GG3.*200;
GG4 = GG4.*200;
SS1 = SS1.*200;
SS2 = SS2.*200;
SS3 = SS3.*200;
SS4 = SS4.*200;

%%
close all
figure(1);
hold on;
box on
plot(GG0, SS1, 'Color',[31 119 180]./255, 'Marker', '+');
plot(GG4, SS4, 'Color',[148 103 189]./255, 'Marker', '*');
plot(GG2, SS2, 'Color',[255 127 14]./255, 'Marker', 'o');
plot(GG3, SS3, 'Color',[214 39 40]./255, 'Marker', '^');
grid on;
xlabel('Traffic Load (packets/s)');
ylabel('Throughput (packets/s)');
xlim([0 2].*200);
legend('Hash Access (adaptive difficulty)', 'Hash Access (fixed difficulty)', 'Aloha (honest net)', 'Aloha (10% rogue)','Location','southeast');
PrintFigToPaper('-depsc', 'benchmark_SG', 16, 'Times New Roman', 7, 1, 0);
PrintFigToPaper('-dpng', 'benchmark_SG', 16, 'Times New Roman', 7, 1, 0);

figure(2);
box on;
hold on;
plot(GG0, QQ1, 'Color',[31 119 180]./255, 'Marker', '+');
plot(GG4, QQ4, 'Color',[148 103 189]./255, 'Marker', '*');
plot(GG2, QQ2, 'Color',[255 127 14]./255, 'Marker', 'o');
plot(GG3, QQ3, 'Color',[214 39 40]./255, 'Marker', '^');
grid on;
xlabel('Traffic Load (packets/s)');
ylabel('Successful Access Prob.');
xlim([0 2].*200);
legend('Hash Access (adaptive difficulty)', 'Hash Access (fixed difficulty)', 'Aloha (honest net)', 'Aloha (10% rogue)','Location','northeast');
PrintFigToPaper('-depsc', 'benchmark_QG', 16, 'Times New Roman', 7, 1, 0);
PrintFigToPaper('-dpng', 'benchmark_QG', 16, 'Times New Roman', 7, 1, 0);

figure(3);
box on;
plot(GG1, DD1, 'Color',[31 119 180]./255, 'Marker', '+');
hold on;
plot(GG4, DD4, 'Color',[148 103 189]./255, 'Marker', '*');
plot(GG2, DD2, 'Color',[255 127 14]./255, 'Marker', 'o');
plot(GG3, DD3, 'Color',[214 39 40]./255, 'Marker', '^');
grid on;
xlabel('Traffic Load (packets/s)');
ylabel('Delay (s)');
xlim([0.1 1.9].*200);
legend('Hash Access (adaptive difficulty)', 'Hash Access (fixed difficulty)', 'Aloha (honest net)', 'Aloha (10% rogue)','Location','northwest');
PrintFigToPaper('-depsc', 'benchmark_DG', 16, 'Times New Roman', 7, 1, 0);
PrintFigToPaper('-dpng', 'benchmark_DG', 16, 'Times New Roman', 7, 1, 0);
