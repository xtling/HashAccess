close all; clc;clear all;

% Trustworthy Grant-Free IoT Access Based on Blockchain
% ADAPTIVE DIFFICULTY REFERENCE TABLE CODE
% the generated table is saved as `dyn.mat` in the root directory.
% the `dyn.mat` is shared among all codes that need to apply adaptive
% difficulty scheme.

% usage of the table generated in this code file
% given the max device number, the diff_list gives the best difficulty value that maximize the throughput
% given the max device number, the diff_delay_list gives the best difficulty value that minimize the delay

%% configuration
leng = 2^15; % simulation length
hardlevel = [0.45:0.05:0.80 0.81:0.01:0.99 0.990:0.001:0.999]; % test difficulty sequence
iot_num_list = 2:200; 
diff_list = [];
G_list = [];
diff_delay_list = [];
G_delay_list = [];

for iot_num_ind = 1:length(iot_num_list)
    iot_num = iot_num_list(iot_num_ind);
    
    if iot_num > 60
        hardlevel = 0.990:0.001:0.999;
    elseif iot_num < 4
        hardlevel = 0.45:0.01:0.81;
    else
        hardlevel = [0.45:0.05:0.80 0.81:0.01:0.99 0.990:0.001:0.999];
    end

    %% global variables for recording performance
    re_delay = zeros(1,length(hardlevel));
    re_delay_n = zeros(1,length(hardlevel));
    re_vacant_rate = zeros(1,length(hardlevel));
    re_avg_occupation_num = zeros(1,length(hardlevel));
    re_conflict_rate = zeros(1,length(hardlevel));
    re_M = zeros(1, length(hardlevel));
    re_N = zeros(1, length(hardlevel));

    %% simulation
    for d = 1:length(hardlevel)
        difficulty = hardlevel(d);
        c = timenow();
        iot_wait_time = zeros(1,iot_num);
        M=0; N=0;
        result_wait = [];
        result_conflict = zeros(1,leng);
        iot_wait_time_n = zeros(1,iot_num);
        r = checkhash(hash_sim(iot_num,leng), difficulty, true);
        all_trans_slot = double(r == true);
        s = sum(r,1);
        M = sum(s);
        result_conflict = s;
        no_conflict_ind = find(result_conflict==1);
        N = length(no_conflict_ind);
        [row,col] = find(r==true);
        [row,row_i] = sort(row);
        col = col(row_i);
        lat_n = diff(col);
        result_wait_n = sum(lat_n(find(lat_n>=0)));
        [~,t] = ismember(no_conflict_ind,col);
        no_conflict_device = row(t)';
        all_trans_slot(sub2ind(size(all_trans_slot),no_conflict_device,no_conflict_ind)) = 2;
        iot_wait_time = zeros(1,iot_num);
        iot_has_record = zeros(1,iot_num);
        iot_has_trans = zeros(1,iot_num);
        conflict_count = sum(result_conflict(find(result_conflict>1)));
        
        
        % calculate delay
        c = timenow();
        iot_wait_time = zeros(1,iot_num);
        result_wait = [];
        result_conflict = zeros(1,leng);
        iot_wait_time_n = zeros(1,iot_num);
        result_wait_n = [];
        for l = 1:leng
            t = num2str(floor(str2num(c)) + l);
            r = checkhash(hash_sim(iot_num,1), difficulty, true);
            s = sum(r);
            result_conflict(l) = result_conflict(l) + s;
            iot_wait_time = iot_wait_time + 1;
            iot_wait_time_n = iot_wait_time_n + 1;
            if s == 1
                result_wait = [result_wait iot_wait_time(r==true)];
                iot_wait_time(r==true) = 0;
            end
            result_wait_n = [result_wait_n iot_wait_time_n(r==true)];
            iot_wait_time_n(r==true) = 0;
        end
        
        re_M(d) = M;
        re_N(d) = N;
        re_delay(d) = mean(result_wait);
        
    end

    %% output the trend curve
    G = re_M./leng;
    S = re_N./leng;
    re_diff = hardlevel(find(S==max(S)));
    re_G = G(find(S==max(S)));
    re_delay_diff = hardlevel(find(re_delay==min(re_delay)));
    re_delay_G = G(find(re_delay==min(re_delay)));
    diff_list = [diff_list re_diff];
    G_list = [G_list re_G];
    diff_delay_list = [diff_delay_list re_delay_diff];
    G_delay_list = [G_delay_list re_delay_G];
    figure(1);
    plot(iot_num,re_diff,'ro');
    hold on;
    figure(2);
    plot(iot_num,re_delay_diff,'ro');
    hold on;
end

%% output figure and save dyn data
close all;
figure(1);
grid on;
save('dyn','diff_list','G_list','iot_num_list','diff_delay_list','G_delay_list');
plot(iot_num_list,diff_list,'k-');
xlabel("X (devices)");
ylabel("Difficulty");


