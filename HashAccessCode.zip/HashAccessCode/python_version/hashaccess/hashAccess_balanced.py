import numpy as np
from hashaccess.gen_adaptive_difficulty import creat_zeros, checkhash, hash_sim


class HashAccessBalanced:
    def __init__(self, leng, iot_num_list, T0, difficulty, opt):
        self.leng = leng
        self.iot_num_list = iot_num_list
        self.T0 = T0
        self.difficulty = difficulty
        self.opt = opt
        self.re_M = creat_zeros(len(self.iot_num_list))
        self.re_G = creat_zeros(len(self.iot_num_list))
        self.re_N = creat_zeros(len(self.iot_num_list))
        self.Q = creat_zeros(len(self.iot_num_list))
        self.re_delay = creat_zeros(len(self.iot_num_list))
        self.re_delay_n = creat_zeros(len(self.iot_num_list))
        self.re_avg_occupation_num = creat_zeros(len(self.iot_num_list))
        self.re_confict_rate = creat_zeros(len(self.iot_num_list))




    def iot_num_change(self):
        for iot_num_ind in range(2, len(self.iot_num_list), 8):
            iot_num_s = self.iot_num_list[iot_num_ind - 1]
            result_wait = []
            iot_num_list = np.append(iot_num_s, iot_num_s)
            for i in range(0, len(iot_num_list)):
                iot_num = iot_num_list[i]
                r = checkhash(hash_sim(int(iot_num), self.leng), difficulty)
                s = r.sum(0)
                self.re_M[iot_num_ind - 1] = self.re_M[iot_num_ind - 1] + sum(s)
                no_conflict_ind = np.argwhere(s == 1)
                self.re_N[iot_num_ind - 1] = self.re_N[iot_num_ind - 1] + len(no_conflict_ind)
                temp_r = dealR(r)
                iot_wait_time = np.zeros((int(iot_num), 1))
                iot_has_record = np.zeros((int(iot_num), 1))
                iot_has_trans = np.zeros((int(iot_num), 1))
                for l in range(0, self.leng):
                    iot_wait_time = iot_wait_time + 1
                    ind1 = np.argwhere(temp_r[:, l] == 1)
                    ind2 = np.argwhere(temp_r[:, l] == 2)
                    if len(ind1) > 0:
                        iot_wait_time[ind1] = np.multiply(iot_has_record[ind1], iot_wait_time[ind1])
                        iot_has_record[ind1] = 1
                        iot_has_trans[ind1] = 0
                    if len(ind2) > 0:
                        if iot_has_trans[ind2] == 0:
                            result_wait = np.append(result_wait, iot_wait_time[ind2])
                            iot_has_record[ind2] = 1
                            iot_has_trans[ind2] = 0
                            iot_wait_time[ind2] = 0
            self.re_delay[iot_num_ind - 1] = np.mean(result_wait)/self.opt
            self.re_G[iot_num_ind - 1] = self.re_M[iot_num_ind - 1]/self.leng/self.opt
            self.Q[iot_num_ind - 1] = self.re_N[iot_num_ind - 1]/self.re_M[iot_num_ind - 1]


            if self.re_G[iot_num_ind - 1] > 2:
                break

        self.re_G = np.delete(self.re_G, np.argwhere(self.re_G == 0))
        self.re_M = np.delete(self.re_M, np.argwhere(self.re_M == 0))
        self.re_N = np.delete(self.re_N, np.argwhere(self.re_N == 0))
        self.re_delay = np.delete(self.re_delay, np.argwhere(self.re_delay == 0))
        self.Q = np.delete(self.Q, np.argwhere(self.Q == 0))

        G = self.re_G
        S = self.re_N/self.leng/self.opt
        Q = self.Q
        re_delay = self.re_delay
        np.savez('loadtest_hash_access_balanced', G = G, S = S, Q = Q, re_delay = re_delay)



def dealR(r):        #未冲突的值设为2
    b = np.argwhere(r == 1)
    c = r.sum(0)
    for i in b:
        if c[i[1]] == 1:
            r[i[0]][i[1]] = 2
    return r


if __name__ =="__main__":
    leng = 2**15
    iot_num_list = np.linspace(2, 300, 299, endpoint=True)
    T0 = 0.001
    difficulty = 0.99
    opt = 2
    hashAccessBalance = HashAccessBalanced(leng, iot_num_list, T0, difficulty, opt)
    hashAccessBalance.iot_num_change()