import numpy as np
from hashaccess.gen_adaptive_difficulty import creat_zeros
import copy
from hashaccess.slotted_aloha import calculateDelay



class slottedAlohaSelfish:
    def __init__(self, MaxIter, selfish_p, selfish_degree, backoff_scaler):
        self.MaxIter = MaxIter
        self.backoff_scaler = backoff_scaler
        self.selfish_p = selfish_p
        self.selfish_degree = selfish_degree
        self.G = creat_zeros(self.MaxIter)
        self.S = creat_zeros(self.MaxIter)
        self.D = creat_zeros(self.MaxIter)
        self.Q = creat_zeros(self.MaxIter)
        self.delay = []
        self.temp = []


    def iot_num_change(self):
        for m in range(2, self.MaxIter, 10):
            self.delay = []
            sel_ind = int(np.floor(self.selfish_p*m))
            T0 = 0.001
            n = 8000
            A = np.random.random((m-sel_ind, n))*self.backoff_scaler
            A = np.floor(A*1000)/1000
            B = np.cumsum(A, axis=1)

            #calculate actions of selfish nodes based on the data above
            A2 = np.random.random((sel_ind, int(np.ceil(n/self.selfish_degree))))*self.backoff_scaler*self.selfish_degree
            A2 = np.floor(A2*1000)/1000
            B2 = np.cumsum(A2, axis=1)
            if sel_ind == 0:
                t = np.ceil(n/self.selfish_degree) - n
            else:
                t = len(B2[0]) - n
            n = n + t
            B = np.hstack((B, np.zeros((m-sel_ind, int(t)))))

            if np.size(B2) != 0:
                B = np.row_stack((B, B2))
            T = np.max(B[0])
            C = np.append([], B)
            D = np.sort(C, axis=None)
            I = np.argsort(C)

            DT = copy.deepcopy(D)
            IT = copy.deepcopy(I)
            temp1 = np.argwhere(DT > T)
            temp2 = np.argwhere(DT == 0)
            temp = np.append(temp1, temp2)
            IT = np.delete(IT, temp)
            DT = np.delete(DT, temp)
            DeviceI = np.ceil((IT+1)/n)
            M = len(np.argwhere(DeviceI <= m - sel_ind))
            ET = np.diff(DT)
            N = findConditionLen(DeviceI, np.append(0, ET), m - sel_ind, T0)


            I = IT
            D = DT
            E = ET
            DeviceI = np.ceil((I + 1)/ n)
            for i in range(1, m + 1):
                ind = np.argwhere(DeviceI == i)
                b = np.argwhere(ind > (len(E) - 1))
                if len(b) > 0:
                    temp_ind = ind[0]
                    ind = np.delete(ind, b)
                    ind = np.append(temp_ind, ind)
                else:
                    ind = np.delete(ind, b)  # 将会删掉第一个数据和满足条件的数据
                ind = np.delete(ind, np.argwhere(ind == 0))
                col_ind = ind[np.argwhere(E[ind] < T0)]
                counter_ind = col_ind
                ok_ind = ind[np.argwhere(E[ind] >= T0)]
                event = np.append(counter_ind, ok_ind[::-1])
                event_ind = np.sort(event)
                event_order = np.argsort(event)  # event中原本的序列索引
                temp = np.argwhere(np.diff(event_order) == 1) + 1
                event_ind = np.delete(event_ind, temp)
                pos = np.searchsorted(event_ind, counter_ind)
                pos = dealPos(pos, event_ind, col_ind)

                if len(np.argwhere(ok_ind == event_ind[-1])) > 0:
                    self.delay = np.append(self.delay, calculateDelay(D, event_ind, pos, T0))

                else:
                    event_ind = np.delete(event_ind, -1)
                    pos = np.searchsorted(event_ind, counter_ind)
                    pos = dealPos(pos, event_ind, col_ind)
                    self.delay = np.append(self.delay, calculateDelay(D, event_ind, pos, T0))

            # 分析
            self.G[m - 1] = M / T * T0  # traffic load (unit:packets/slot)
            self.S[m - 1] = N / T * T0
            self.Q[m - 1] = N / M
            self.D[m - 1] = self.temp = np.mean(self.delay)

            if self.G[m - 1] > 1.9999:
                break

        GG = np.delete(self.G, np.argwhere(self.G == 0))
        SS = np.delete(self.S, np.argwhere(self.S == 0))
        DD = np.delete(self.D, np.argwhere(self.D == 0))
        QQ = np.delete(self.Q, np.argwhere(self.Q == 0))

        np.savez('benchmark_honest_selfish_aloha', GG = GG, SS = SS, DD = DD, QQ = QQ)

def findConditionLen(a, b, less, more):
    c = []
    if len(a) == len(b):
        for k in range(0, len(a)):
            if a[k] <= less and b[k] >= more:
                c = np.append(c, k)
    return len(c)

def dealPos(pos, event_ind, col_ind):
    c = []
    for k in range(0, len(pos) -1):
        if pos[k] == pos[k + 1]:
            c = np.append(c, k + 1)
    pos = np.delete(pos, c)
    b = []
    for i in range(0, len(pos)):
        if pos[i] < len(event_ind) - 1:
            if len(np.argwhere(col_ind == event_ind[pos[i]])) == 0 :
                b = np.append(b, i)
        else:
            break
    pos = np.delete(pos, b)
    return pos


def findArg(a, b):
    c = np.array([1])
    for k in range(0, len(a)):
        for m in range(0, len(b)):
            if a[k] == b[m]:
                c = np.append(c, m)
                break
    c = np.delete(c, 0)
    return c



if __name__ =="__main__":
    MaxIter = 2000
    selfish_p = 0.1  #selfish node proportion
    selfish_degree = 0.5 #selfish degree, the lower, the more selfish
    backoff_scaler = 0.1
    slotted_aloha_selfish = slottedAlohaSelfish(MaxIter, selfish_p, selfish_degree, backoff_scaler)
    slotted_aloha_selfish.iot_num_change()

