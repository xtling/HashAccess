import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from components.actor import Actor
from components.producer import Producer
from components.contract import Contract, Status
from components.common import hash_sim, is_hash_meets_difficulty
from components.blockchain import Account
import time
from hashaccess.hashAccess import HashAccess_simulation
import numpy as np


class Iot_device:

    def __init__(self):
        self.data_packet = None
        self.is_malicious_device = False   #该设备是否为恶意设备
        self.money = 1000     #假设物联网设备自身含有1000块钱
        self.hash_time = 0    #通过接入点的验证的次数
        self.Whether_to_grant_ap_authorization = False     #物联网设备是否授权给接入点
        self.is_pass_ap_authorization = False  #是否通过了接入点的验证
        self.blockchain_account = Account()   #物联网设备的区块链账号
        self.HashAccess_simulation = None     #物联网设备的hashAccess的数值仿真
        self.service_time = 0             #物联网设备从申请服务到退回押金所花费的时间

    def register_data_packet(self, data_packet):
        if isinstance(data_packet, Data_packet):
            self.data_packet = data_packet

    def register_HashAccess_simulation(self, hashAccess_simulation):
        if isinstance(hashAccess_simulation, HashAccess_simulation):
            self.HashAccess_simulation = hashAccess_simulation

    def ap_veritification(self, actor):         #接入点验证
        if self.hash_time == 0:
            print("The Iot devices begin trying accessing the AP")
        if isinstance(actor, Actor):
            if is_hash_meets_difficulty(self.data_packet.hash, actor.difficulty):
                print("The packet of iot device passed the authentication of the access point")
                self.hash_time += 1
                self.data_packet.contract.hash = self.data_packet.hash
                self.is_pass_ap_authorization = True
            else:
                print("The packet of iot device doesn't pass the authentication of the access point")
                self.hash_time += 1
                self.is_pass_ap_authorization = False

    def grant_ap_signature(self, actor):        #物联网设备授予接入点数字签名
        if isinstance(actor, Actor):
            if self.is_pass_ap_authorization:
                self.Whether_to_grant_ap_authorization = True
                actor.whether_to_get_iot_authorization = True


    def accessing_when_failed(self, actor):         #当首次尝试失败后，后续继续尝试接入
        if not self.is_pass_ap_authorization:
            if isinstance(actor, Actor):
                while True:
                    time.sleep(0.005)  # 如果接入失败的话，过5ms， 尝试下一次接入。
                    self.data_packet.hash_once()
                    self.ap_veritification(actor)
                    if self.is_pass_ap_authorization:
                        print(
                            "after trying {} times, iot devices finally pass the authentification of the access point".format(
                                self.hash_time))
                        self.data_packet.contract.hash = self.data_packet.hash
                        break
        else:
            print("iot device has passed the authtification")


    def pay_deposit(self):        #支付押金
        if self.money - self.data_packet.contract.penalties >= 0:
            if self.money - self.data_packet.contract.deposit >= 0:
                self.money -= self.data_packet.contract.deposit
                self.blockchain_account.deposit += self.data_packet.contract.deposit
                self.blockchain_account.whether_to_pay_deposit = True
                print("iot devices have pay the deposit")
                return True
        else:
            print("iot devices must pay enough deposit to avoid malicious devices")
            return False


    def recover_deposit(self):     #收回押金
        if self.data_packet.contract.status == Status.finished and self.data_packet.contract.is_blockchain_receive_contract:
            self.money += self.blockchain_account.deposit
            self.blockchain_account.deposit = 0
            self.blockchain_account.whether_to_recover_deposit = True
            if self.blockchain_account.whether_to_recover_deposit:
                print("iot devices quit the B-RAN and recover the deposit at the same time")


    def calculate_average_service_time(self, actor, producer):  #统计平均服务耗时（假设针对一份固定的合约）
        service_time_list = list()
        if isinstance(actor, Actor) and isinstance(producer, Producer):
            for i in range(0, 1000):
                self.money = 1000        #初始化物联网设备的余额
                self.data_packet.hash = 1    #初始化hash值
                start = time.perf_counter()  # 物联网设备开始申请服务的起始点
                self.ap_veritification(actor)  # 接入点验证
                if not self.is_pass_ap_authorization:
                    self.accessing_when_failed(actor)
                if self.is_pass_ap_authorization:
                    if not self.pay_deposit():
                        return
                    register_iot_devices(self, actor)
                    self.grant_ap_signature(actor)
                if actor.ap_action() == -1:  # 接入点的工作来了
                    return
                self.recover_deposit()  # 物联网设备收回押金（或者所剩的押金）
                end = time.perf_counter()
                service_time_list.append(end - start)
            average_service_time = np.mean(service_time_list)
            return average_service_time


class Data_packet:

    def __init__(self, hash):
        self.contract = None
        self.hash = hash


    def register_contract(self, temp_contract):
        if isinstance(temp_contract, Contract):
            self.contract = temp_contract


    def hash_once(self):
        self.hash = hash_sim()


def register_iot_devices(iot_devices, actor):
    if isinstance(actor, Actor) and isinstance(iot_devices, Iot_device):
        actor.iot_devices = iot_devices


def main():
    c = np.load('dyn.npy.npz')
    diff_list = c['k_diff_list']
    leng = 2 ** 11  # simulation times
    diff1 = 0.98  # fixed difficulty
    iot_num_list = c['k_iot_num_list']
    T0 = 0.001  # slot duration
    hashAccess_simulation = HashAccess_simulation(diff1, iot_num_list, leng, diff_list)
    iot_devices = Iot_device()
    data_packet = Data_packet(hash=1)
    iot_devices.register_HashAccess_simulation(hashAccess_simulation)
    iot_devices.HashAccess_simulation.iot_num_change_for_hashAccess()        #进行hashAccess的数值仿真
    iot_devices.register_data_packet(data_packet)
    iot_devices.data_packet.hash_once()
    actor = Actor(2, 5, difficulty=4, recording_threshold=0)
    producer = Producer(block_time=12, arrival_time=2, service_time=5, difficulty=10,
                        block_size=1000, is_mining_for_real=False, is_collecting_realtime=True)
    actor.register_producer(producer)
    producer.do_contract_generator()
    data_packet.register_contract(producer.temp_contract)    #物联网设备准备就绪（数据包和合约都准备好了）
    actor.broadcast_hash(iot_devices.data_packet.contract)  # 接入点广播hash值，传到合约中
    start = time.perf_counter()                     #物联网设备开始申请服务的起始点
    iot_devices.ap_veritification(actor)        #接入点验证
    if not iot_devices.is_pass_ap_authorization:
        iot_devices.accessing_when_failed(actor)
    if iot_devices.is_pass_ap_authorization:
        if not iot_devices.pay_deposit():
            return
        register_iot_devices(iot_devices, actor)
        iot_devices.grant_ap_signature(actor)
    if actor.ap_action() == -1:             #接入点的工作来了
        return
    iot_devices.recover_deposit()          #物联网设备收回押金（或者所剩的押金）
    end = time.perf_counter()
    iot_devices.service_time = end - start
    print("The time it takes for IoT devices from applying for services to returning the deposit is: {} s".format(iot_devices.service_time))
    # iot_devices.calculate_average_service_time(actor, producer)   #如果有必要的话，可以统计平均服务耗时

if __name__ == "__main__":
    main()




