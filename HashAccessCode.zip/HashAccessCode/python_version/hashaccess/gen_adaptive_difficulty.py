# -*- coding:utf-8 -*-

from numpy import zeros
import numpy as np
import random

import copy


class AdaptiveDifficulty:

    def __init__(self, leng, hd1, hd2, hd3, hardlevel ,iot_num_list):
        self.leng = leng
        self.hd1 = hd1
        self.hd2 = hd2
        self.hd3 = hd3
        self.hardlevel = hardlevel
        self.iot_num_list = iot_num_list
        self.diff_list = []
        self.G_list = []
        self.diff_delay_list = []
        self.G_delay_list = []
        self.G = []


    def iot_num_change(self):
        for k in range(0, len(self.iot_num_list)):
            iot_num = self.iot_num_list[k]

            if iot_num > 60:
                self.hardlevel = self.hd3
            elif iot_num < 4:
                self.hardlevel =self.hd1
            else:
                self.hardlevel = self.hd2

            re_M = []
            re_N = []
            re_delay = creat_zeros(len(self.hardlevel)) + 100
            avg = creat_zeros(len(self.hardlevel)) + 100
            #simulation
            for d in range(0, len(self.hardlevel)):
                difficulty = self.hardlevel[d]
                r = checkhash(hash_sim(int(iot_num), self.leng), difficulty)
                s = r.sum(0)
                M = sum(s)
                result_conflict = s
                no_conflict_ind = np.argwhere(s == 1)
                N = len(no_conflict_ind)

                # calculate delay
                iot_wait_time = zeros((int(iot_num), 1))
                result_wait = []
                result_conflict = zeros((1, self.leng))
                iot_wait_time_n = zeros((int(iot_num), 1))
                result_wait_n = []
                for l in range(0, self.leng):
                    rr = checkhash(hash_sim(int(iot_num), 1), difficulty)
                    ss = rr.sum(0)
                    result_conflict[0][l] = result_conflict[0][l] + ss
                    iot_wait_time = iot_wait_time + 1
                    iot_wait_time_n = iot_wait_time_n + 1
                    if ss == 1:
                        result_wait = np.append(result_wait, iot_wait_time[np.where(rr == 1)])
                        iot_wait_time[np.where(rr == 1)] = 0
                    result_wait_n = np.append(result_wait_n, iot_wait_time_n[np.where(rr==1)])
                    iot_wait_time_n[np.where(rr == 1)] = 0
                re_M = np.append(re_M, M)
                re_N = np.append(re_N, N)
                avg[d] = np.mean(result_wait)
                if avg[d] != 0:
                    re_delay[d] = avg[d]

            #output the trend curve
            G = re_M/self.leng
            S = re_N/self.leng
            re_diff  = self.hardlevel[find_max(S)]
            re_G = G[find_max(S)]
            re_delay_diff = self.hardlevel[find_min(re_delay)]
            re_delay_G = G[find_min(re_delay)]
            self.diff_list = np.append(self.diff_list, re_diff)
            self.G_list = np.append(self.G_list, re_G)
            self.diff_delay_list = np.append(self.diff_delay_list, re_delay_diff)
            self.G_delay_list = np.append(self.G_delay_list, re_delay_G)

        np.savez('dyn.npy', k_diff_list = self.diff_list, k_G_list = self.G_list, k_diff_delay_list = self.diff_delay_list, K_G_delay_list = self.G_delay_list, k_iot_num_list = self.iot_num_list)




def checkhash(hash, diff):     #大于difficulty的返回1，否则返回0
    hash_copy = copy.deepcopy(hash)
    r = np.where(hash_copy > diff, 1, 0)
    return r



def hash_sim(m, n):           #生成m*n的0到1的随机数
    return np.random.random((m, n))

def find_max(S):            #返回最大值对应的索引
    max = S[0]
    arg = 0
    for i in range(1, len(S)):
        if S[i] > max:
            max = S[i]
            arg = i
    return arg


def find_min(S):         #返回最小值对应的索引
    min = S[0]
    arg = 0
    for i in range(1, len(S)):
        if S[i] < min:
            min = S[i]
            arg = i
    return arg


def creat_zeros(l):   #生成全0的列表
    a = []
    for k in range(0, l):
        a = np.append(a, 0)
    return a







if __name__ == "__main__":
    leng = 2**10
    hardlevel = []
    hd1 = np.linspace(0.45, 0.81, 37, endpoint = True)
    hdd2 = np.linspace(0.45, 0.80, 8, endpoint = True)
    hdd3 = np.linspace(0.81, 0.99, 19, endpoint= True)
    hd = np.linspace(0.990, 0.999, 10, endpoint= True)
    hd2 = np.append(hdd2, np.append(hdd3, hd))
    hd3 = hd
    iot_num_list = np.linspace(2, 200, 199, endpoint= True)

    adaptiveDifficulty = AdaptiveDifficulty(leng, hd1, hd2, hd3, hardlevel, iot_num_list)
    adaptiveDifficulty.iot_num_change()
