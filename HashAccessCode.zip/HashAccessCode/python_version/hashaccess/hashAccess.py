import numpy as np
from hashaccess.gen_adaptive_difficulty import creat_zeros, checkhash, hash_sim
from numpy import zeros
import copy
import time




class HashAccess_simulation:

    def __init__(self, diff1, iot_num_list, leng, diff_list):
        self.diff1 = diff1
        self.iot_num_list = iot_num_list
        self.leng = leng
        self.diff_list = diff_list
        self.re_M = creat_zeros(len(self.iot_num_list))  # list of transmission counter within the test time
        self.re_N = creat_zeros(len(self.iot_num_list))  # list of  successful transmission counter within the test time
        self.re_delay = creat_zeros(len(self.iot_num_list))  # list of transmission delay
        self.re_delay_n = creat_zeros(
            len(self.iot_num_list))  # list of transmission delay without re-transmission circumstances
        self.re_conflict_rate = creat_zeros(len(self.iot_num_list))  # list of average conflict rate within the test time
        self.re_vacant_rate = creat_zeros(len(self.iot_num_list))
        self.re_avg_occupation_num = creat_zeros(len(self.iot_num_list))# list of average occupation rate within the test time
        self.re_conflict_rate = creat_zeros(len(self.iot_num_list))

        # with adaptive difficulty
        self.re_M_dyn = creat_zeros(len(self.iot_num_list))
        self.re_N_dyn = creat_zeros(len(self.iot_num_list))
        self.re_delay_dyn = creat_zeros(len(self.iot_num_list))
        self.re_delay_n_dyn = creat_zeros(len(self.iot_num_list))
        self.re_vacant_rate_dyn = creat_zeros(len(self.iot_num_list))
        self.re_avg_occupation_num_dyn = creat_zeros(len(self.iot_num_list))
        self.re_conflict_rate_dyn = creat_zeros(len(self.iot_num_list))

    def iot_num_change_for_hashAccess(self):           #针对固定难度与自适应难度的仿真
        print("Begin simulation for hashaccess")
        start = time.perf_counter()
        for iot_num_ind in range(1, len(self.iot_num_list), 5):
            iot_num = self.iot_num_list[iot_num_ind]

            if iot_num < 40:
                diff2 = 0.9793
            if 40 < iot_num < 60:
                if len(np.argwhere(self.iot_num_list == iot_num)) > 0:
                    diff2 = self.diff_list[np.where(self.iot_num_list == iot_num)]  # 特定iot_num对应diff_list的difficulty值
            if iot_num > 60:
                diff2 = 0.976

            diff_list_two = np.append(self.diff1, diff2)
            for diff in range(0, 2):
                difficulty = diff_list_two[diff]
                result_conflict = zeros((1, self.leng))
                iot_wait_time = zeros((int(iot_num), 1))
                iot_wait_time_n = zeros((int(iot_num), 1))
                result_wait = []
                result_wait_n = []

                for l in range(0, self.leng):
                    rr = checkhash(hash_sim(int(iot_num), 1), difficulty)
                    ss = rr.sum(0)
                    if diff == 0:
                        self.re_M[iot_num_ind] = self.re_M[iot_num_ind] + ss
                    else:
                        self.re_M_dyn[iot_num_ind] = self.re_M_dyn[iot_num_ind] + ss
                    result_conflict[0][l] = result_conflict[0][l] + ss
                    iot_wait_time = iot_wait_time + 1
                    iot_wait_time_n = iot_wait_time_n + 1
                    if ss == 1:
                        result_wait = np.append(result_wait, iot_wait_time[np.where(rr == 1)])
                        iot_wait_time[np.where(rr == 1)] = 0
                        if diff == 0:
                            self.re_N[iot_num_ind] = self.re_N[iot_num_ind] + 1
                        else:
                            self.re_N_dyn[iot_num_ind] = self.re_N_dyn[iot_num_ind] + 1
                    result_wait_n = np.append(result_wait_n, iot_wait_time_n[np.where(rr == 1)])
                    iot_wait_time_n[np.where(rr == 1)] = 0
                #update global vars
                if diff == 0:       #fixed difficulty
                    if len(np.argwhere(result_conflict > 1)) > 0:
                        conflict_count = result_conflict[np.where(result_conflict > 1)].sum()
                    else:
                        conflict_count = 0
                    self.re_delay[iot_num_ind] = np.mean(result_wait)/200
                    self.re_delay_n[iot_num_ind] = np.mean(result_wait_n)/200
                    self.re_vacant_rate[iot_num_ind] = len(np.argwhere(result_conflict == 0))/len(result_conflict)
                    self.re_avg_occupation_num[iot_num_ind] = np.sum(result_conflict)/self.leng
                    self.re_conflict_rate[iot_num_ind] = conflict_count/result_conflict.sum()
                else:
                    if len(np.argwhere(result_conflict > 1)) > 0:
                        conflict_count = result_conflict[np.where(result_conflict > 1)].sum()
                    else:
                        conflict_count = 0
                    self.re_delay_dyn[iot_num_ind] = np.mean(result_wait)/200
                    self.re_delay_n_dyn[iot_num_ind] = np.mean(result_wait_n)/200
                    self.re_vacant_rate_dyn[iot_num_ind] = len(np.argwhere(result_conflict == 0)) / len(result_conflict)
                    self.re_avg_occupation_num_dyn[iot_num_ind] = np.sum(result_conflict)/self.leng
                    self.re_conflict_rate_dyn[iot_num_ind] = conflict_count / result_conflict.sum()
            if self.re_M[iot_num_ind]/self.leng > 1.9999:
                break
        self.re_M = remove_zeros(self.re_M)
        self.re_N = remove_zeros(self.re_N)
        self.re_delay = remove_zeros(self.re_delay)

        self.re_M_dyn = remove_zeros(self.re_M_dyn)
        self.re_N_dyn = remove_zeros(self.re_N_dyn)
        self.re_delay_dyn = remove_zeros(self.re_delay_dyn)

        G = self.re_M/self.leng * 200
        S = self.re_N/self.leng * 200
        Q = divide(S, G)

        np.savez('benchmark_honest_hash_access_without_control_for_second', G = G, S = S, Q = Q, re_delay = self.re_delay)

        G_dyn = self.re_M_dyn / self.leng * 200
        S_dyn = self.re_N_dyn / self.leng * 200
        Q_dyn = divide(S_dyn, G_dyn)
        np.savez('benchmark_honest_hash_access_for_second', G_dyn= G_dyn, S_dyn = S_dyn, Q_dyn = Q_dyn, re_delay_dyn=self.re_delay_dyn, G = G)
        end = time.perf_counter()
        print("The simulation of Hash Access has finished, it takes {} s".format(end - start))
        time.sleep(2)


def remove_zeros(a):          #去除为0的项
    c = copy.deepcopy(a)
    b = []
    for k in range(0, len(c)):
        if c[k] != 0:
            b= np.append(b, c[k])
    return b

def divide(a,b):    #对应一维的
    c = []
    if len(a) == len(b):
        for k in range(0, len(a)):
            c = np.append(c, a[k]/b[k])
    return c










if __name__ == "__main__":
    c = np.load('dyn.npy.npz')
    diff_list = c['k_diff_list']
    leng = 2 ** 11      # simulation times
    diff1 = 0.98         # fixed difficulty
    iot_num_list_ha = c['k_iot_num_list']  # iot_num_list
    iot_num_list = c['k_iot_num_list']
    T0 = 0.001          # slot duration
    hashAccess = HashAccess_simulation(diff1, iot_num_list, leng, diff_list)
    hashAccess.iot_num_change()

#Hash Access
#hash access with fixed and adaptive difficulty






