import numpy as np
from hashaccess.slotted_aloha import calculateDelay, findArg, dealPos
from hashaccess.gen_adaptive_difficulty import creat_zeros
import copy


class slottedAlohaBalanced:
    def __init__(self, MaxIter, backoff_scaler, opt):
        self.opt = opt
        self.MaxIter = MaxIter
        self.backoff_scaler = backoff_scaler
        self.G = creat_zeros(self.MaxIter)
        self.S = creat_zeros(self.MaxIter)
        self.D = creat_zeros(self.MaxIter)
        self.Q = creat_zeros(self.MaxIter)
        self.delay = []


    def iot_num_change(self):
        for mm in range(2, self.MaxIter, 3):
            self.delay = []
            n = 8000
            M = 0
            N = 0
            T0 = 0.001

            temp_mm = np.append(mm, mm)
            for i in range(0, len(temp_mm)):
                m = int(temp_mm[i])
                A = np.random.random((m, n)) * self.backoff_scaler
                A = np.floor(A * 1000) / 1000
                B = np.cumsum(A, axis=1)
                T = B[0][n - 1]
                C = np.append([], B)
                D = np.sort(C, axis=None)
                I = np.argsort(C)

                DT = copy.deepcopy(D)
                DT = np.delete(DT, np.argwhere(DT > T))
                M = M + len(DT)
                ET = np.diff(DT)
                N = N + len(np.argwhere(ET >= T0))


                #calculate delay
                I = np.delete(I, np.argwhere(C[I] > T))
                D = np.delete(D, np.argwhere(D > T))
                E = ET
                DeviceI = np.ceil((I + 1) / n)
                for i in range(1, m + 1):
                    ind = np.argwhere(DeviceI == i)
                    b = np.argwhere(ind > (len(E) - 1))
                    if len(b) > 0:
                        temp_ind = ind[0]
                        ind = np.delete(ind, b)
                        ind = np.append(temp_ind, ind)
                    else:
                        ind = np.delete(ind, b)  # 将会删掉第一个数据和满足条件的数据
                    ind = np.delete(ind, np.argwhere(ind == 0))
                    col_ind = ind[np.argwhere(E[ind] < T0)]
                    counter_ind = col_ind
                    ok_ind = ind[np.argwhere(E[ind] >= T0)]
                    event = np.append(counter_ind, ok_ind[::-1])
                    event_ind = np.sort(event)
                    event_order = np.argsort(event)  # event中原本的序列索引
                    temp = np.argwhere(np.diff(event_order) == 1) + 1
                    event_ind = np.delete(event_ind, temp)
                    pos = np.searchsorted(event_ind, counter_ind)
                    pos = dealPos(pos, event_ind, col_ind)
                    # pos1 = findArg(counter_ind, event_ind)

                    if len(np.argwhere(ok_ind == event_ind[-1])) > 0:
                        self.delay = np.append(self.delay, calculateDelay(D, event_ind, pos, T0))
                    # elif len(np.argwhere(counter_ind == event_ind[-1])) > 0:
                    else:
                        event_ind = np.delete(event_ind, -1)
                        pos = np.searchsorted(event_ind, counter_ind)
                        pos = dealPos(pos, event_ind, col_ind)
                        self.delay = np.append(self.delay, calculateDelay(D, event_ind, pos, T0))
            # analyse and save result
            self.G[mm - 1] = M / T * T0/self.opt
            self.S[mm - 1] = N / T * T0/self.opt
            self.Q[mm - 1] = N / M
            self.D[mm - 1] = np.mean(self.delay)

            if self.G[mm - 1] > 2:
                break

        GG = np.delete(self.G, np.argwhere(self.G == 0))
        SS = np.delete(self.S, np.argwhere(self.S == 0))
        DD = np.delete(self.D, np.argwhere(self.D == 0))
        QQ = np.delete(self.Q, np.argwhere(self.Q == 0))

        np.savez('loadtest_slotted_aloha_balanced', GG=GG, SS=SS, DD=DD, QQ=QQ)




if __name__ == "__main__":
    opt = 2
    MaxIter = 2000
    backoff_scaler = 0.1
    slotted_aloha_balaced = slottedAlohaBalanced(MaxIter, backoff_scaler, opt)
    slotted_aloha_balaced.iot_num_change()