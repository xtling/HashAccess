# -*- coding:utf-8 -*-

from numpy import zeros
import numpy as np
import random
import matplotlib.pyplot as plt

import copy


class one_iot:

    def __init__(self, leng, hardlevel):
        self.leng = leng
        self.hardlevel = hardlevel

    def iot_diff_change(self):
        avg = creat_zeros(len(self.hardlevel))
        for d in range(0, len(self.hardlevel)):
            difficulty = self.hardlevel[d]
            # calculate delay
            iot_wait_time = 0
            result_wait = []
            for l in range(0, self.leng):
                rr = checkhash(hash_sim(1, 1), difficulty)
                ss = rr.sum(0)
                iot_wait_time = iot_wait_time + 1
                if ss == 1:
                    result_wait = np.append(result_wait, iot_wait_time)
                    iot_wait_time = 0
            avg[d] = np.mean(result_wait)/200
        plt.scatter(self.hardlevel, avg)
        plt.xlabel("difficulty")
        plt.ylabel("delay")
        plt.show()



def checkhash(hash, diff):     #大于difficulty的返回1，否则返回0
    hash_copy = copy.deepcopy(hash)
    r = np.where(hash_copy > diff, 1, 0)
    return r


def hash_sim(m, n):           #生成m*n的0到1的随机数
    return np.random.random((m, n))


def find_max(S):            #返回最大值对应的索引
    max = S[0]
    arg = 0
    for i in range(1, len(S)):
        if S[i] > max:
            max = S[i]
            arg = i
    return arg


def find_min(S):         #返回最小值对应的索引
    min = S[0]
    arg = 0
    for i in range(1, len(S)):
        if S[i] < min:
            min = S[i]
            arg = i
    return arg


def creat_zeros(l):   #生成全0的列表
    a = []
    for k in range(0, l):
        a = np.append(a, 0)
    return a


def creat_hardlevel(n):
    hardlevel = list()
    for i in range(0, n+1):
        hardlevel.append(1 - 1/2**i)
    hardlevel.append(1)
    return hardlevel


if __name__ == "__main__":
    leng = 1000
    hardlevel = creat_hardlevel(10)
    IOT = one_iot(leng, hardlevel)
    IOT.iot_diff_change()
