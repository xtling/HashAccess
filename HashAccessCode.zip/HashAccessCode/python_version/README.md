# Python Hash Access with BRANChain


## NOTICE

1. To prepare your device for running simulations, please run `install_dependencies.bat`.
2. The core functions and packages have been enclosed in folder `hashaccess` and `components`. Scripts for simulating Hash Access are stored in `hashaccess`. The B-RAN foundations are stored in `components`.
3. If you try running scripts in `hashaccess`, please remember to run them from the current folder where the `readme.md` is stored.

## Usage

To try the Python version of Hash Access, you have to open the current folder in Pycharm or other available IDEs, and run the following scripts to see outputs.

- hashaccess/hashAccess_balanced.py
  - Running the pure Hash Access in a multi-operator network with balance loads
- hashaccess/hashAccess_unbalanced.py
  - Running the pure Hash Access in a multi-operator network with unbalance loads
- hashaccess/hashAccess_with_bran.py
  - Running the full Hash Access with BRANChain
  - Output the average access latency





