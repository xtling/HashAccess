# -*- coding:utf-8 -*-

from components.block import Block


class Account:

    def __init__(self):
        self.deposit = 0
        self.whether_to_pay_deposit = False
        self.whether_to_recover_deposit = False

class BlockChain:

    def __init__(self):
        self.block_list = list()
        self.len = 0


    def length(self):
        return self.len

    def push(self, b):
        if isinstance(b, Block) and b.hash < 1 / (2 ** b.difficulty):
            b.id = self.len + 1
            b.prev_block = self.get_latest()
            self.block_list.append(b)
            self.len += 1
        else:
            raise Exception("error when pushing a new instance into blockchain")

    def get_latest(self, confirmation=0):
        if self.length() > confirmation:
            return self.block_list[-confirmation - 1]     #返回块列表最后一项
        return None

    def get_last_block_hash(self):          #返回最后一块的hash值
        if len(self) > 0:
            return self.block_list[-1].hash        #[-1]代表最后一项
        return None

    def drop(self, lind=-1, b=None):
        # This function does not affect the length of this blockchain （不影响区块链的长度）
        if lind > 0:  # use list index to pop items（使用列表索引弹出序列）
            self.block_list.pop(lind)
        if b is not None:  # use block id to remove items
            for block in self.block_list:
                if block.id == b.id:
                    self.block_list.remove(block)
                    break

    def __iter__(self):
        return self.block_list

    def __len__(self):
        return self.length()

    def __repr__(self):
        return '\n'.join([str(x) for x in self.block_list])


if __name__ == "__main__":
    chain = BlockChain()
    b = Block(222, 232, 2, 0.5)
    b2 = Block(333, 323, 3, 0.8)
    try:
        chain.push(b)
    except Exception as e:
        print(str(e))
    b.mine()
    chain.push(b)
    b2.mine()
    chain.push(b2)
    print(len(chain))
    print(chain)
    print(chain.get_latest())
    print(chain.get_last_block_hash())
