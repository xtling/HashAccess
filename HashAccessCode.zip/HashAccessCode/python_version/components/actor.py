# -*- coding:utf-8 -*-

import threading
import time
from components.common import get_average, deep_copy
from components.contract import Contract, Status
from components.producer import Producer


class TimeSpot:

	def __init__(self, ind, time, type):  #构造函数
		self.index = ind
		self.time = time
		self.type = type        # 0:end / 1:start

	def __lt__(self, other):
		if self.time < other.time:
			return True
		return False

	def __repr__(self):
		return "({},{})".format(self.time, self.type)    #输出时间、类型


class Actor:
	# Act as access point

	def __init__(self, num_channels, confirmation, difficulty, recording_threshold = 4, effective_latency = 50):
		self.num_channels = num_channels
		self.confirmation = confirmation    # confirmation must be controlled by actors
		self.recording_thre = recording_threshold       # let simulation run for a couple of seconds and then record
		self.contract_id = 0
		self.timestamp_after_recording_threshold = -1
		self.isr_cnt = 0                     #immediate service request count
		self.esr_cnt = 0                    # effective service request count
		self.lat_list = list()                #将元组转换为列表
		self.lat_before_service_list = list()
		self.lat_effective_list = list()
		self.effective_latency = effective_latency      # real seconds, used for calculating effective throughput
		self.timeline = dict()                 #new empty dictionary
		self.cnt_before_thre = 0			# count of contracts before recording threshold
		self.stop_flag = False
		self.producer = None                # producer should be registered under the current actor
		self.difficulty = difficulty
		self.fee_received = 0               #假设初始时，接入点还未收到物联网设备给的服务费，为0
		self.whether_to_get_iot_authorization = False    #是否得到了物联网设备的授权
		self.iot_devices = None
		self.whether_blockchain_receive_contract = False  #区块链是否接受了合约
		self.penalties = 100            #检测到恶意设备时，假设罚金为100（假设为服务费的10倍）


#act_setvice的功能，将合同，时间戳导入，计算延迟，把正在进行的合同放入在timeline列表中，并能够及时反馈合同的时间以及运行状态
	def act_service(self, c, timestamp):           #c是合同  timestamp暂且当作一个数字
		# Tear off finished contracts.(终止已经完成的合同)
		if len(self.timeline) > 0:          #如果timeline不为空
			t_timeline = deep_copy(self.timeline)     #深复制一个t_timeline,此时值为timeline，而后就是一个独立的个体。
			for (k, v) in self.timeline.items():					# id:(contract,timestamp <- injection time)   k:key  v:value
				if timestamp >= (v[1] + v[0].service_time):			# v[1]:start_time, v[0].st:service_time
					t_timeline.pop(k)                               #将已完成的合同弹出，timeline只包含正在运行的合同
			self.timeline = t_timeline   #key
		# Add new contracts and calculate latency immediately（添加新的合同并且立即计算延时）
		if isinstance(c, Contract):              #判断c，是否属于Contract类
			t_timeline = deep_copy(self.timeline)
			self.contract_id += 1              #contract_id加1(合同数加一)
			self.timeline[str(self.contract_id)] = [c, timestamp]    # id:(contract,timestamp <- injection time)
			# (Fixed) record a new timestamp for analysis     （记录一个新的时间戳来分析）
			if self.timestamp_after_recording_threshold < 0 and self.contract_id > self.recording_thre:
				self.timestamp_after_recording_threshold = timestamp
			if len(self.timeline) <= self.num_channels:     # ISRs: Immediate Service Request（即时的服务请求）
				# (IMPORTANT FUNCTION) recording latency, isr（即时服务请求）, esr（有效服务请求）, etc.
				lat_val = c.service_time + timestamp - c.timestamp
				lat_val_without_service = timestamp - c.timestamp  #对于main（）里的合同c1,c2,c3,c4  该值为0
				if self.contract_id > self.recording_thre:
					self.isr_cnt += 1
					self.lat_list.append(lat_val)
					self.lat_before_service_list.append(lat_val_without_service)  #服务之前的延时，两时间戳的差
					# For Effective Latency Stats.
					# if lat_val_without_service <= self.effective_latency * self.producer.scaler:
					if lat_val_without_service <= self.effective_latency :
						self.esr_cnt += 1   #有效次数加一
						self.lat_effective_list.append(lat_val_without_service)
				else:
					self.cnt_before_thre += 1        #如果没有超过规定的阈值，则计数加一
			else:                                           # Not ISRs
				wait_cnt = len(self.timeline) - self.num_channels     #等待服务的数量
				timeline_lst = list()            #创建一个空列表
				timespot_ind = 0
				for (k, v) in t_timeline.items():           #（1,1） （10，0） 1秒的时候开始，10s的时候结束
					timeline_lst.append(TimeSpot(timespot_ind, v[1], 1))       # 0:end / 1:start
					timespot_ind += 1
					timeline_lst.append(TimeSpot(timespot_ind, v[1]+v[0].service_time, 0))
					timespot_ind += 1
				timeline_lst = sorted(timeline_lst)
				start_service_time = c.timestamp
				# For those are not ISRs, they have to be reset to a new service start time.
				if wait_cnt > 0:							# update start time only when c is not ISR
					for ts in timeline_lst:    				# k:timestamp, v:start/end
						k = ts.time
						v = ts.type
						if v == 0:
							wait_cnt -= 1
						if wait_cnt == 0:
							start_service_time = k
							break
					t_timeline[str(self.contract_id)] = [c, start_service_time]
				self.timeline = deep_copy(t_timeline)
				# (IMPORTANT FUNCTION) recording latency, isr, esr, etc.
				lat_val = c.service_time + start_service_time - c.timestamp
				lat_val_without_service = start_service_time - c.timestamp
				if self.contract_id > self.recording_thre:
					self.isr_cnt += 1
					self.lat_list.append(lat_val)
					self.lat_before_service_list.append(lat_val_without_service)
					# For Effective Latency Stats.
					# if lat_val_without_service <= self.effective_latency * self.producer.scaler:
					if lat_val_without_service <= self.effective_latency :
						self.esr_cnt += 1
						self.lat_effective_list.append(lat_val_without_service)
				else:
					self.cnt_before_thre += 1
			# Set finished State of the contract  (设置合同的完成状态)
			c.change_status(Status.finished)
			self.timeline[str(self.contract_id)][0].change_status(Status.finished)
		else:         #不满足上述两个大条件时
			raise Exception("error when pushing a non-contract instance into the actor") #当推入非合同实例给接入点时出错

	def get_avg_lat(self):        #求self.lat_list的平均值
		return get_average(self.lat_list)

	def get_avg_before_service_lat(self):  #求lat_before_service_list的平均值
		return get_average(self.lat_before_service_list)

	def get_avg_efflat(self):  #求lat_effective_list的平均值
		return get_average(self.lat_effective_list)

	def get_isr_cnt(self):         #返回即时服务请求数目
		return self.isr_cnt

	def get_esr_cnt(self):          #返回有效服务请求
		return self.esr_cnt

	def get_req_cnt(self):  #得到请求数目
		return len(self.lat_list)

	def get_req_cnt_before_threshold(self):
		return self.cnt_before_thre

	def broadcast_hash(self, c):
		if isinstance(c, Contract):
			c.target_hash = 1/2**self.difficulty

	def ap_action(self):       #物联网设备的数据包通过接入点的验证后，接入点的工作
		if self.whether_to_get_iot_authorization:       #如果此值为真，表明物联网设备通过了接入点的验证
			self.action()
			# self.producer.push_contract_to_transaction_pool()  #将合约推入到合约池
			# self.iot_devices.data_packet.contract.change_status(Status.in_pool)
			# self.producer.do_block_generator()         #生成一个块，来装合约
			# self.producer.block.mine()          #必然能找到符合难度的哈希值
			# self.producer.push_block_to_blockchain(self.producer.block) #将块推入到区块链中
			# self.iot_devices.data_packet.contract.is_blockchain_receive_contract = True
			# self.is_blockchain_receive_contract()  #接入点判断区块链是否接受了合约
			# self.iot_devices.data_packet.contract.change_status(Status.in_chain)
			# self.detect_malicious_iot_devices()     #接入点检测是否含有恶意的物联网设备
			# self.act_service(self.iot_devices.data_packet.contract, self.iot_devices.data_packet.contract.timestamp)   #接入点服务



	def is_blockchain_receive_contract(self,c):   #检查主链是否接受了合约
		if isinstance(c, Contract):
			if c.is_blockchain_receive_contract:
				self.whether_blockchain_receive_contract = True
				return self.whether_blockchain_receive_contract


	def charge(self):    #物联网设备向接入点缴费
		if self.whether_blockchain_receive_contract and self.whether_to_get_iot_authorization and self.iot_devices.data_packet.contract.status == Status.finished and self.iot_devices.data_packet.contract.is_blockchain_receive_contract:
			if self.iot_devices.money - self.iot_devices.data_packet.contract.service_fee >= 0:
				self.fee_received += self.iot_devices.data_packet.contract.service_fee
				self.iot_devices.money -= self.iot_devices.data_packet.contract.service_fee
				print("iot devices pay successfully")
			elif self.iot_devices.blockchain_account.deposit - self.iot_devices.data_packet.contract.service_fee >= 0:
				self.fee_received += self.iot_devices.data_packet.contract.service_fee
				self.iot_devices.blockchain_account.deposit -= self.iot_devices.data_packet.contract.service_fee
				print("iot devices use deposit to pay the service fee")
			elif self.iot_devices.blockchain_account.deposit - self.iot_devices.data_packet.contract.service_fee < 0:
				print("the deposit iot devices have pay cann't pay the service fee")
				return -1

		else:
			print("there are some errors")

	def punish(self):  #惩罚（罚款）
		if self.iot_devices.is_malicious_device:
			if self.iot_devices.blockchain_account.deposit - self.penalties >= 0:
				self.iot_devices.blockchain_account.deposit -= self.penalties
				self.fee_received += self.penalties
			elif self.iot_devices.money - self.penalties >= 0:
				self.iot_devices.money -= self.penalties
				self.fee_received += self.penalties
			elif self.iot_devices.money + self.iot_devices.blockchain_account.deposit - self.penalties >= 0:
				self.iot_devices.blockchain_account.deposit = 0
				self.iot_devices.money = self.iot_devices.money - (self.penalties - self.iot_devices.blockchain_account.deposit)
			else:
				self.iot_devices = None
				print("the money or the deposit of iot device is not enough for penalty")




	def detect_malicious_iot_devices(self):         #检测是否含有恶意设备
		if not self.iot_devices.data_packet.hash < 1/2**self.difficulty:
			self.iot_devices.is_malicious_device = True
			print("the system have detected malicious iot devices")
			self.punish()                  #有恶意设备的话，对其进行惩罚（罚款）

	def register_producer(self, producer):    #注册（把producer传给actor里的producer）
		if isinstance(producer, Producer):
			producer.confirmation = self.confirmation
			self.producer = producer
		else:
			raise Exception("non-producer instance cannot be registered under this actor")


#如果actor中的producer中区块链长度大于了接入点的认证数量，那么返回producer中[-confirmation-1]项的data
#并将合同的状态（如果不是完成并且正在被服务）改为正在被服务，然后进入接入点服务
	def __act_contracts_from_latest_confirmed_block(self): #来自最近认证的块的合同
		if len(self.producer.blockchain) > self.confirmation:
			self.stop_action()
			contract_list = self.producer.blockchain.get_latest(confirmation=self.confirmation).data     #返回对应的块的data，也就是合同列表
			for cind in range(0, len(contract_list)):
				if contract_list[cind].status != Status.finished and contract_list[cind].status != Status.acting:
					contract_list[cind].change_status(Status.acting)
					if self.is_blockchain_receive_contract(contract_list[cind]):    #监测主链是否接受了该合约
						self.act_service(contract_list[cind], self.producer.now())
					if self.charge() == -1:  # 接入点收费了
						return -1
			self.iot_devices.recover_deposit()  #物联网设备收回押金（或者所剩的押金）
			self.iot_devices.service_time = self.iot_devices.calculate_time()
			print(
				"The time it takes for IoT devices from applying for services to returning the deposit is: {} s".format(
					self.iot_devices.service_time))




	def __monitor_producer(self):
		if not isinstance(self.producer, Producer):
			return                    #这里返回的应该是布尔值
		while True:
			if self.stop_flag:
				self.stop_flag = False       #为真则取反
				break
			time.sleep(0.005)		# Infinite loop always needs a break! (If you don't want any errors)
			if self.producer.is_waiting_for_actor():    #返回的是actor_event的flag的相反值
				self.__act_contracts_from_latest_confirmed_block()
				self.producer.notify_actor_finish()

	def action(self):
		# Magic happens here that action can be run in a standalone thread while sharing all class members.
		if not isinstance(self.producer, Producer):
			return False
		# Call Actor will first activate the registered Producer !
		self.producer.action()			# you should not call acting producer and actor at the same time.
		self.th = threading.Thread(target=Actor.__monitor_producer, args=(self,))  #线程要执行的动作为Actor里的__monitor_producer，args是传入target函数里的位置参数，是一个元组。
		self.th.setDaemon(True) #主线程结束时，子线程也会被结束掉
		self.th.start()   #启动线程
		return True

	def stop_action(self):
		self.stop_flag = True
		# Call Actor to stop will de-activate the Producer at the same time ! （叫停Actor，同时去关闭Producer）
		self.producer.stop_action()		# you should not call stopping producer and actor at the same time.






if __name__ == "__main__":    #当文件被直接运行时，下列的模块才会被运行。
	# actor = Actor(2, 5, recording_threshold=0)
	# c1 = Contract(1, 9, 1)   # identity, service_time, timestamp  （合同刚被建立 created = 1）
	# c2 = Contract(2, 7, 2)
	# c3 = Contract(3, 5, 4)
	# c4 = Contract(4, 10, 9)
	# actor.act_service(c1, 1)
	# actor.act_service(c2, 2)
	# actor.act_service(c3, 4)
	# actor.act_service(c4, 9)
	# print(actor.get_avg_lat())  # should be 9.25
	# print(actor.get_isr_cnt())  # should be 1.5
    #
	# actor2 = Actor(3, 5,  recording_threshold=0)
	# actor2.act_service(c1, 1)
	# actor2.act_service(c2, 2)
	# actor2.act_service(c3, 4)
	# actor2.act_service(c4, 9)
	# print(actor2.get_avg_lat())  # should be 7.75
	# print(actor2.get_isr_cnt())  # should be 4

	print("BEGIN...")
	actor3 = Actor(2, confirmation=2, difficulty= 4)
	producer = Producer(block_time=10, arrival_time=5, service_time=5,
						difficulty=15, block_size=1000, is_mining_for_real=False,
						is_collecting_realtime=False)
	actor3.register_producer(producer)      # you should always register the corresponding producer first
	actor3.action()
	time.sleep(10)
	actor3.stop_action()
	# print(producer)
	# print(get_average(producer.record_blocksize) / producer.scaler)
	# print(get_average(producer.record_blocktime) / producer.scaler)
	# print(get_average(producer.record_reqinterval) / producer.scaler)
	# print(get_average(producer.record_reqtime) / producer.scaler)
	# print(actor3.get_avg_lat() / producer.scaler)
	# print(actor3.get_isr_cnt() / actor3.get_req_cnt())

	# Why confirmation=2 & block_time=10 & arrival_interval=10 & service_time=1 could produce average_latency=41 ?
	# Solve: average_latency = block_time(because blocktime>=arrival_interval, L=arrival_interval) + (confirmation + 1) * block_time + service_time
	# The contract generated between block0 and block1 will be assembled when block1 is released.
	# Then, the contract will be published in block2 and wait until block4 is released.
	# The average latency is certainly much longer than expected.
	# Change is_collecting_realtime = True if you want the latency to be a little shorter.
