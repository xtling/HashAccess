# -*- coding:utf-8 -*-

import random
import os
import time
import datetime
import copy
import numpy as np
from scipy import stats



def random_exp(mean):
    return random.expovariate(1 / mean)         #随机生成符合指数分布的随机数



def random_possion(mean):
    return float(np.random.poisson(mean, 1)[0])     #泊松分布


def random_uniform(start, end):                 #在给定区间内生成一个实数
    return random.uniform(start, end)


def sim_mine(difficulty):    #挖矿仿真（先生成一个0-1之间的随机数，符合的返回True和随机数的值）
    # The project does not have to calculate the real hash value for time-saving concerns.（并不计算实际的hash值）
    x = random_uniform(0, 1)
    target_hash = 1 / (2 ** difficulty)
    if x < target_hash:
        return (True, x)
    return (False, x)


def get_mine_interval(difficulty):        #返回一个指数分布随机数(挖矿时间间隔)
    return random_exp(2 ** difficulty)


def hash_sim():
    return random_uniform(0, 1)

def is_hash_meets_difficulty(hash, difficulty):       #hash值是否符合难度
    return hash < 1 / (2 ** difficulty)           #2的difficulty次幂


def dot_divide(lst, n):
    new_lst = list()  # for deep copying the list
    for ii in range(0, len(lst)):
        new_lst.append(lst[ii] / n)           #除操作
    return new_lst


def deep_copy(dat):               #深复制
    return copy.deepcopy(dat)


def save_data(filename, data, isTimestamp=False, simLen=-1, rwMode="a+"):  #保存数据
    if not os.path.exists("result"):
        os.makedirs("result")
    data = list(data)
    dir = "result/{}".format(filename)         #dir是一个文件目录，/result/filename
    if isTimestamp:
        pieces = dir.split('.')
        if len(pieces) > 1:
            dir = "".join(pieces[0:len(pieces) - 1]) + "_" + str(time.time()) + "." + pieces[-1]
        else:
            dir = dir + str(time.time()) + ".txt"
    with open(dir, rwMode) as f:
        if simLen > 0:
            f.write("{}\n".format(simLen))
        for dele in data:
            f.write(str(dele))
            f.write("\n")
    return dir


def out_info(aval=0.5,      # arrival interval  到达间隙
             bval=0.5,      # block interval
             cval=1,        # service duration
             diff=10,       # consensus difficulty  共识难度
             conval=2,      # number of confirmations  认证数量
             sval=2,        # amount of servers         服务数量
             reqmax=1000,   # max number of test requests
             scnt=0,        # amount of tested requests
             avglat=0,      # current average latency
             isr=0.0,       # current IST rate
             eff_lat=0.0,   # effective latency
             eff_val=0.0,   # current effective latency value
             is_progress=False):
    # See below for usage of this output function
    percent = scnt / reqmax
    if not is_progress:
        pre_str_seq = list()
        pre_str_seq.append("=" * 70)
        pre_str_seq.append(" BRANChain Simulator  @{}".format(datetime.datetime.now()))
        pre_str_seq.append("=" * 70)
        pre_str_seq.append("Basic Parameters")
        pre_str_seq.append("aval=[{}]  bval=[{}]  cval=[{}]  conval=[{}]  sval=[{}]".format(aval,
                                                                                            bval,
                                                                                            cval,
                                                                                            conval,
                                                                                            sval))
        pre_str_seq.append("current throughput rho=[{}]".format(1/aval/sval*cval))
        pre_str_seq.append("diff=[{}]  reqmax=[{}]  time=[{}]  efflat=[{}]".format(diff, reqmax,
                                                                                   datetime.datetime.now(),
                                                                                   eff_lat))
        pre_str_seq.append("")
        pre_str_seq.append("Monitoring Parameters")
        pre_str_seq.append("L:average latency, I:immediate service rate")
        pre_str_seq.append("")
        print("\n".join(pre_str_seq))
    print_progress(percent, avglat, isr, eff_val)


def print_progress(percent, avglat, isr, eff_val):
    max_progressbar_len = 36
    p = int(percent * max_progressbar_len)
    s_l = ">" * (p)
    s_r = " " * (max_progressbar_len-p)
    print("[%.1f/100 L%.1f I%.1f E%.1f] [%s%s]" % (percent * 100, avglat, isr, eff_val, s_l, s_r), flush=True, end='\r')


def debug(msg, cls=None):  #调试
    # Control Parameters
    is_debug = True
    if is_debug:
        if cls == None:
            print("{}[R] Main: {}".format(str(datetime.datetime.now()), msg))
        else:
            print("{}[D] {}: {}".format(str(datetime.datetime.now()), cls.__class__.__name__, msg))


def get_average(lst):        #得到平均值
    if len(lst) == 0:
        return 0
    sum = 0
    for x in lst:
        sum += x
    return sum / len(lst)


def get_lower_group_average(lst, r):
    max_val = max(lst)
    min_val = min(lst)
    thre = min_val + (max_val - min_val) * r
    ok_group = list()
    for l in lst:
        if l <= thre:
            ok_group.append(l)
    return get_average(ok_group)


def calc_confidence_interval_normal(lst, lvl=0.95):  #计算置信区间正态分布
    # Tip: it uses Normal Dist. to fit the data
    mean, std = np.mean(lst), np.std(lst, ddof=1)
    conf_interval = stats.poisson.interval(lvl, loc=mean, scale=std)
    return [mean, conf_interval[0], conf_interval[1]]


def calc_confidence_interval_poisson(lst, lvl=0.95):     #计算置信区间泊松分布
    # Tip: it uses Poisson Dist. to fit the data
    # Thanks to : https://stackoverflow.com/questions/14813530/poisson-confidence-interval-with-numpy
    # Thanks to : https://wenku.baidu.com/view/09504bc089eb172ded63b787.html
    X = np.sum(lst)
    n = len(lst)
    lb = X / n - stats.norm.ppf(lvl / 2) * np.sqrt(X) / n
    ub = X / n + stats.norm.ppf(lvl / 2) * np.sqrt(X) / n
    return [X / n, ub, lb]

if __name__ == "__main__":
    sim_len = 100000

    sum = 0
    for i in range(sim_len):
        x = random_exp(5)
        if x <= 0:
            print(x)
        sum += x
    print(sum / sim_len)

    sum = 0
    for i in range(sim_len):
        sum += random_possion(5)
    print(sum / sim_len)

    sum = 0
    for i in range(sim_len):
        sum += random_uniform(0, 1)
    print(sum / sim_len)

    data = [123, 567]
    filename = "common_test.txt"
    print(save_data(filename, data, isTimestamp=True))
    print(save_data(filename, data, isTimestamp=False))

    cnt = 0
    for i in range(sim_len):
        if sim_mine(2)[0]:
            cnt += 1
    print(cnt / sim_len)          #挖矿成功率

    lst = [1, 2, 3, 4, 4, 5, 5, 5, 5, 5, 4, 4, 3, 2, 1]
    print(calc_confidence_interval_poisson(lst, lvl=0.95))

    out_info(scnt=1, reqmax=10, is_progress=False)
    time.sleep(2)
    out_info(scnt=2, reqmax=10, is_progress=True)
    time.sleep(2)
    out_info(scnt=3, reqmax=10, is_progress=True)
    time.sleep(2)
    out_info(scnt=4, reqmax=10, is_progress=True)
    time.sleep(2)
    out_info(scnt=5, reqmax=10, is_progress=True)
    time.sleep(2)
    out_info(scnt=6, reqmax=10, is_progress=True)