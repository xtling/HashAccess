# -*- coding:utf-8 -*-

from enum import Enum

class Status(Enum):
	created = 1  # indicate that the contract is just created
	in_pool = 2  # indicate that the contract has been pushed into transaction pool
	in_chain = 3  # indicate that the contract has been recorded by blockchain
	queueing = 4  # indicate that the contract has got enough confirmations and is waiting for service
	acting = 5  # indicate that the contract is being served by an AP
	finished = 6  # indicate that the contract has finished

class Contract:

	def __init__(self, identity, service_time, timestamp):
		self.id = identity
		self.service_time = service_time
		self.timestamp = timestamp
		self.status = Status.created
		self.service_fee = 10     #合同的服务费,假设为10块钱
		self.deposit = 100       #该物联网设备在进入B-RAN时，存入其区块链账户的押金,该值应当不小于服务费和罚金
		self.target_hash = 1
		self.hash = 1            #物联网设备的数据包的哈希值
		self.penalties = 100     #如果检测到恶意设备，所需缴纳的罚金
		self.is_blockchain_receive_contract = False          #作为主链是否接受了合约的依据

	def __repr__(self):
		return "id:" + str(self.id) + " service_time:" + str(self.service_time) + " timestamp:" + \
		       str(self.timestamp) + " status:" + str(self.status) + " target_hash:" + str(self.target_hash) + " service_fee" + str(self.service_fee) + " deposit" + str(self.deposit)


	def change_status(self, status):
		self.status = status


if __name__ == "__main__":
	c = Contract(1, 10, 2019)
	print(c)
	c.change_status(Status.acting)
	print(c)