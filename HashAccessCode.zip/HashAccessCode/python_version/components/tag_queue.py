# -*- coding:utf-8 -*-

class Queue:

	def __init__(self):
		self.queue = list()
		self.queue_args = list()

	def push(self, o, args):
		self.queue.append(o)
		self.queue_args.append(args)

	def pop(self):        #弹出首位
		if self.len() > 0:
			o = self.queue[0]
			a = self.queue_args[0]
			self.queue.pop(0)
			self.queue_args.pop(0)
			return (o, a)
		return None

	def len(self):
		return self.queue.__len__()

	def clear(self):          #初始化
		self.__init__()

	def __len__(self):
		return self.len()

	def __repr__(self):
		return str(self.queue)


if __name__ == "__main__":
	q = Queue()
	q.push(1, 7)
	q.push(2, 8)
	q.push(3, 9)
	q.push(4, 10)
	q.push(5, 11)
	q.push(6, 12)
	print(q)
	print(len(q))
	# print(q.to_list())
	print("pop one element")
	print(q.pop())
	print(q)
	print(len(q))
	print("pop one element")
	print(q.pop())
	print(q)
	print(len(q))