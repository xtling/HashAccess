# -*- coding:utf-8 -*-

from components.common import sim_mine, is_hash_meets_difficulty, random_uniform

class Block:

	def __init__(self, timestamp, data, difficulty, prev_hash):
		# Hash value in this project is set between 0 and 1 for simplicity.
		self.timestamp = timestamp
		self.data = data
		self.prev_hash = prev_hash  # Previous hash would be used in mining under real circumstance, but not in this project
		self.difficulty = difficulty
		# Following parameters are filled when the block is either pushed into blockchain or mined by miners
		self.hash = 1
		self.id = -1
		self.prev_block = -1

	def is_valid(self):          #是否符合哈希，是否有效
		return is_hash_meets_difficulty(self.hash, self.difficulty)

	def set_valid_hash(self):           #返回一个0到2**self.difficulty分之一之间的随机数，设置一个符合难度的哈希值
		self.hash = random_uniform(0, 1 / (2**self.difficulty))
		return self.hash

	def hash_once(self):           #哈希一次，如果成功的话，返回True,此时hash值也是符合相应难度的，如果不符合，返回False
		(flag, val) = sim_mine(self.difficulty)    #返回一个布尔值（是否符合）和生成的0-1的随机数
		if flag and not is_hash_meets_difficulty(self.hash, self.difficulty):
			self.hash = val
			return True
		return False

	def mine(self):         #必然能找到符合当前难度的哈希值
		if is_hash_meets_difficulty(self.hash, self.difficulty):
			return True
		while not self.hash_once():
			pass
		return True

	def __repr__(self):
		if not isinstance(self.data, list):
			len_data = 1
		else:
			len_data = len(self.data)
		return "Block #{} @ {}: difficulty {}, data length {}, previous hash {}, my hash {}". \
			format(str(self.id), str(self.timestamp), str(self.difficulty), str(len_data), str(self.prev_hash), str(self.hash))


if __name__ == "__main__":
	b = Block(222, [12,34], 2, 0.5)
	print(b.hash_once())
	b.mine()
	print(b)
	print(b.hash_once())    # the hash method will not function when block hash has already met the difficulty requirement.
	print(b)

