# -*- coding:utf-8 -*-

import time
import threading
from enum import Enum
from components.blockchain import BlockChain
from components.block import Block
from components.tag_queue import Queue
from components.contract import Contract, Status
from components.common import random_exp, get_mine_interval, deep_copy


class EventType(Enum):
    block = 0
    contract = 1
    none = 2


class TimeEvent:

    def __init__(self, type, time, data):
        self.type = type
        self.time = time
        self.data = data

    def __cmp__(self, other):
        if self.time < other.time:
            return -1
        elif self.time == other.time:
            return 0
        else:
            return 1

    def __lt__(self, other):
        if self.time < other.time:
            return 1
        return 0

    def __repr__(self):
        return "Event type:{}, time:{}, data:{}\n".format(str(self.type), str(self.time), str(self.data))


class Producer:
    # Act as contract generators and miners      （合约生成者和矿工）
    # But it is more like a time manager           （但更像时间管理员）
    # The miners defined in this class support virtual mining (uses arranged block time) or real hash attempting
    #此类中定义的挖掘器支持虚拟挖掘（使用排列的块时间）或实际哈希尝试
    # Thus, in the following implementation, two branches are designed for each functional method
    #因此，在下面的实现中，为每个函数方法设计了两个分支

    def __init__(self,
                 block_time,
                 arrival_time,
                 service_time,
                 difficulty,
                 block_size=10000,
                 is_mining_for_real=False,
                 is_collecting_realtime=False,
                 confirmation=2):
        # blocktime = 1 / lambda_b
        # arrival_time = 1 / lambda_a
        self.block_time = block_time  # Block generating interval (real world time)
        self.arrival_time = arrival_time  # Contract requesting interval (real world time)
        self.service_time = service_time  # Contract service time (real world time)
        self.difficulty = difficulty  # Mining difficulty
        self.block_size = block_size  # Block size limit
        self.is_mining_for_real = is_mining_for_real  # Fake mining is based on events
        self.is_collecting_realtime = is_collecting_realtime  # Whether miners collecting data during mining
        self.confirmation = confirmation  # Ordered Confirmations during actor registration
        self.req_ind = 0  # Index of the requesting contract
        self.scaler = 2 ** difficulty / self.block_time  # Equals to reference_time/real_time
        self.t_ref = 0  # The ONLY time reference in this project and it should be referenced by other classes
        # Initialize pre-service entities
        self.blockchain = BlockChain()
        self.transaction_pool = Queue()
        self.events_seq = list()
        self.block = None
        # Initialize events
        self.stop_flag = False  # Indication of stopping producer's action
        self.actor_event = threading.Event()  # Indication of waiting for actor's action（等待接入点行动的指示）
        # Recording parameters
        self.record_blocktime = list()
        self.record_blocksize = list()
        self.record_reqinterval = list()
        self.record_reqtime = list()
        self.record_test = list()
        self.temp_contract = None


#按照指数分布，生成了请求时间和服务时间，并将他们添加到相应的列表当中，其次就是生成合约（id，服务时间，时间戳）
#然后，创建一个TimeEvent对象（合同类型，时间，内容：生成的合约）添加到event_seq序列中去，并排序，返回时间戳（当前时间+请求时间）
    def do_contract_generator(self):      #合约生成
        # req_interval = int(random_exp(self.arrival_time * self.scaler))  # Request Interval obeys exponential dist.（请求间隔服从指数分布。）     ？？？？？
        # serv_time = int(random_exp(self.service_time * self.scaler))  # Service Time obeys exponential dist.
        req_interval = 0  # Request Interval obeys exponential dist.（请求间隔服从指数分布。）     （real world time）
        serv_time = 0  # Service Time obeys exponential dist.                                    （real world time）
        self.record_reqinterval.append(req_interval)
        self.record_reqtime.append(serv_time)

        if not self.is_mining_for_real:  # means the system is driven by planned events
            c = Contract(self.req_ind, serv_time, self.now() + req_interval)  #（id，severce_time, 时间戳）
            self.req_ind += 1  #合同数加1
            self.temp_contract = c
            self.__add_events(TimeEvent(EventType.contract, self.now() + req_interval, c))   #加入到消息队列
            return c.timestamp          #返回self.now() + req_interval
        else:  # means the system is controlled by current decisions
            c = Contract(self.req_ind, serv_time, self.now() + req_interval)
            self.temp_contract = c
            self.req_ind += 1
            self.__add_events(TimeEvent(EventType.contract, self.now() + req_interval, c))
            return c.timestamp



#根据难度的指数分布，生成块的间隔时间，并添加到相应的序列当中去。对于is_mining_for_real = false当交易池不为空并且data的长度小于块的大小时，弹出交易
#的第一项的‘o’,并将其添加到data中，之后生成一个块（时间戳，data，difficulty,区块链中上一个块的hash值），并设置有效的
#哈希值，之后生成TimeEvent(块，时间，b),添加到event_seq序列中去
    def do_block_generator(self):       #块生成
        block_interval = int(get_mine_interval(self.difficulty))     #块的间隔是根据难度的指数分布生成的
        self.record_blocktime.append(block_interval)
        # Note that a new block is generated when one gets the latest block information,
        # thus, all the information is not collected when block is mined but shortly after the last publish of a block.
        data = list()  # No propagation delay is considered here   （未考虑传播延迟）
        if not self.is_mining_for_real:  # means the system is driven by planned events
            while len(self.transaction_pool) > 0 and len(data) < self.block_size:
                data.append(self.transaction_pool.pop()[0])   #弹出交易池最后一项，然后把它添加到data中
            self.block = Block(self.now() + block_interval, data, self.difficulty, self.blockchain.get_last_block_hash())
            self.block.set_valid_hash()  # this process must be made, otherwise the blockchain.push will not function properly
            self.__add_events(TimeEvent(EventType.block, self.now() + block_interval, self.block))
            return self.now() + block_interval      #返回时间戳
        else:  # means the system is controlled by current decisions
            if self.block is None:
                while len(self.transaction_pool) > 0 and len(data) < self.block_size:
                    data.append(self.transaction_pool.pop()[0])
                self.block = Block(self.now(), data, self.difficulty, 1.0)  #把哈希值初始化为1.0
                self.block.hash_once()       #然后去尝试挖一次矿
            elif not self.block.is_valid():      #block不为空但无效
                if self.is_collecting_realtime:
                    data = self.block.data
                    while len(self.transaction_pool) > 0 and len(data) < self.block_size:
                        data.append(self.transaction_pool.pop()[0])
                    self.block.data = data
                self.block.hash_once()
            elif self.block.is_valid():         #block有效
                self.record_blocksize.append(len(self.block.data))
                self.__add_events(TimeEvent(EventType.block, self.now(), self.block))
                self.block = None
            return self.now()


#对应于假挖矿模式，先将stop_flag置为false，生成一个块和合约。接下来进入循环（stop_flag为true时终止）：
#对于contract，推入到交易池之后，再生成一个contract，对于block，推入到区块链之后，再生成一个块，此时将actor_event
#这个进程的flag置为false，调用wait，阻塞该进程。
    def __action(self):
        self.stop_flag = False
        if not self.is_mining_for_real:  # means the system is driven by planned events
            # The fake mining mode has the privilege of moving forward timeline instantly（假挖掘模式有权立即向前移动时间线）
            self.do_block_generator()  # init
            # self.do_contract_generator()  # init
            while True:
                if self.stop_flag:
                    break
                if len(self.events_seq) > 0:
                    e = self.events_seq.pop(0)
                    if e.type == EventType.contract:           #1
                        self.calibrate_time(e.time)             #t_ref=e.time
                        self.transaction_pool.push(e.data, self.now())
                        e.data.change_status(Status.in_pool)
                        # self.do_contract_generator()
                    elif e.type == EventType.block:            #0
                        self.calibrate_time(e.time)
                        if self.is_collecting_realtime:
                            dat = e.data.data  # e.data is Block and e.data.data is Transaction list(交易列表)
                            while len(self.transaction_pool) > 0 and len(dat) < self.block_size:   #把合约添加到block的data中
                                dat.append(self.transaction_pool.pop()[0])
                            e.data.data = dat
                        self.record_blocksize.append(len(e.data.data))
                        self.blockchain.push(e.data)
                        contract_list = self.blockchain.get_latest().data
                        for i in range(0, len(contract_list)):
                            contract_list[i].change_status(Status.in_chain)
                            contract_list[i].is_blockchain_receive_contract = True
                        self.do_block_generator()
                        self.actor_event.clear()  # clear the incoming actor event     #将flag->flase
                        self.actor_event.wait()  # wait for incoming actor event       #阻塞
                        self.actor_event.clear()  # clear the incoming actor event
                    self.__clear_cache()  # clear cache of finished blocks（清除已经完成块的缓存）
        else:  # means the system is controlled by current decisions
            self.do_contract_generator()  # init: only the contract generator should be initialized
            while True:
                if self.stop_flag:
                    self.stop_flag = False
                    break
                self.do_block_generator()  # block generator should work every moment
                if len(self.events_seq) > 0:
                    e = self.events_seq[0]
                    if e.type == EventType.contract and e.time == self.now():    #contract  1
                        self.transaction_pool.push(e.data, self.now())
                        self.events_seq.pop(0)
                        self.do_contract_generator()  # contract generator only works when the last one has finished
                    elif e.type == EventType.block and e.time == self.now():      #block     0
                        self.blockchain.push(e.data)
                        self.events_seq.pop(0)
                        self.actor_event.clear()  # clear the incoming actor event
                        self.actor_event.wait()  # wait for incoming actor event
                        self.actor_event.clear()  # clear the incoming actor event
                self.calibrate_time(self.now() + 1)  # time increment is set to 1 in real mining mode  (t_ref = self.now() + 1 )

    def action(self): #开启线程，执行_action()
        # Magic happens here that action can be run in a standalone thread while sharing all class members.
        self.th = threading.Thread(target=Producer.__action, args=(self,))       #程序入口为__action（）
        self.th.setDaemon(True)        #主线程结束，子线程也会结束
        self.th.start()

    def stop_action(self):
        self.stop_flag = True

    def push_contract_to_transaction_pool(self):
        if len(self.events_seq) > 0:
            e = self.events_seq.pop(0)
            if e.type == EventType.contract:  # 1
                self.calibrate_time(e.time)  # t_ref=e.time
                self.transaction_pool.push(e.data, self.now())

    def push_block_to_blockchain(self, b):
        if isinstance(b, Block):
            self.blockchain.push(b)

    def notify_actor_finish(self):
        self.actor_event.set()         #flag->True

    def is_waiting_for_actor(self):
        return not self.actor_event.is_set()   #判断event的flag是否为true

    def now(self):
        return self.t_ref

    def calibrate_time(self, t):   #校准时间
        self.t_ref = t

    def __clear_cache(self):      #清除缓存
        # This function is only for fake mining mode   （这个功能仅适用于假的挖矿模式）
        t_block_list = self.blockchain.block_list.copy()  #返回一个浅复制
        for block in t_block_list:
            cnt_finished_contract = 0
            for c in block.data:
                if c.status == Status.finished:        #6
                    cnt_finished_contract += 1
            if cnt_finished_contract == len(block.data) and block.id < self.blockchain.length() - self.confirmation:
                # drop this block off. all data in this block has finished
                self.blockchain.drop(b=block)
                break

    def __add_events(self, e):
        self.events_seq.append(e)
        self.events_seq = sorted(self.events_seq)

    def __repr__(self):
        return "Producer block_time:{}, arrival_time:{}, service_time:{}, difficulty:{}, block_size:{}, " \
               "is_mining_for_real:{}, is_collected_realtime:{} \n{}". \
            format(str(self.block_time), str(self.arrival_time), str(self.service_time), str(self.difficulty),
                   str(self.block_size),
                   str(self.is_mining_for_real), str(self.blockchain), str(self.is_collecting_realtime))


if __name__ == "__main__":
    producer = Producer(block_time=10, arrival_time=2, service_time=5, difficulty=10,
                        block_size=1000, is_mining_for_real=False, is_collecting_realtime=True)
    producer.action()
    time.sleep(1)
    producer.notify_actor_finish()  # notifying producer that the actor has finished its current job.
    time.sleep(1)
    producer.notify_actor_finish()  # notifying producer that the actor has finished its current job.
    time.sleep(1)
    producer.notify_actor_finish()  # notifying producer that the actor has finished its current job.
    time.sleep(1)
    producer.stop_action()
    print(producer)  # you should only see 4 blocks

    producer2 = Producer(block_time=10, arrival_time=2, service_time=5, difficulty=10,
                         block_size=1000, is_mining_for_real=True, is_collecting_realtime=True)
    producer2.action()
    time.sleep(1)
    producer2.notify_actor_finish()
    time.sleep(1)
    producer2.notify_actor_finish()
    time.sleep(1)
    producer2.notify_actor_finish()
    time.sleep(1)
    producer2.stop_action()
    print(producer2)
    # In real mining mode, you should see exact amount of requests that is equal to one in the previous 4 blocks.
    print(producer2.req_ind - len(producer2.transaction_pool) - 1)
